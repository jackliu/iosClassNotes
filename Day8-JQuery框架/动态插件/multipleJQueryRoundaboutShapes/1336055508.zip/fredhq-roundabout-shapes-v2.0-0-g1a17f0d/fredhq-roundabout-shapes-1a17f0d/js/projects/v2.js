$(document).ready(function() {	
	$('ul#example-lazySusan').roundabout();
	$('ul#example-waterWheel').roundabout({shape: 'waterWheel'});
	$('ul#example-figure8').roundabout({shape: 'figure8'});
	$('ul#example-square').roundabout({shape: 'square'});
	$('ul#example-conveyorBeltLeft').roundabout({shape: 'conveyorBeltLeft'});
	$('ul#example-conveyorBeltRight').roundabout({shape: 'conveyorBeltRight'});
	$('ul#example-diagonalRingLeft').roundabout({shape: 'diagonalRingLeft'});
	$('ul#example-diagonalRingRight').roundabout({shape: 'diagonalRingRight'});
	$('ul#example-theJuggler').roundabout({shape: 'theJuggler'});
	$('ul#example-goodbyeCruelWorld').roundabout({shape: 'goodbyeCruelWorld'});
	$('ul#example-rollerCoaster').roundabout({shape: 'rollerCoaster'});
	$('ul#example-tearDrop').roundabout({shape: 'tearDrop'});
});
