//
//  GSIndexView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-3-7.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSIndexView.h"


@implementation GSIndexView
@synthesize bgImageview, indexDetailViewScroll, indexDetailViewArray;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		if (!self.bgImageview) 
		{
			UIImageView *tempImageview = [[UIImageView alloc] init];
			self.bgImageview = tempImageview;
			//[tempImageview release];
		}
		if (!self.indexDetailViewScroll)
		{
			UIScrollView *tempScroll = [[UIScrollView alloc] init];
			self.indexDetailViewScroll = tempScroll;
			//[tempScroll release];
		}
		if (!self.indexDetailViewArray) 
		{
			NSMutableArray *tempArray = [[NSMutableArray alloc] init];
			self.indexDetailViewArray = tempArray;
			//[tempArray release];
		}
		
		[self.bgImageview setFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
		self.bgImageview.image = [UIImage imageNamed:@"index.png"];
		self.indexDetailViewScroll.backgroundColor = [UIColor clearColor];
		[self addSubview:self.bgImageview];
		
		[self.indexDetailViewScroll setFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
		self.indexDetailViewScroll.showsHorizontalScrollIndicator = NO;
		[self addSubview:self.indexDetailViewScroll];
		
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/



@end
