//
//  GSForum.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-6.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSForum.h"


@implementation GSForum
@synthesize forumsFuzzyImage;
@synthesize firstShowResourceArray;
@synthesize allResourceArray;


- (id)init {
	self = [super init];
	if (self) {
		if (!self.forumsFuzzyImage) 
		{
			GSCoverImage *aGSCoverImage = [[GSCoverImage alloc] init];
			self.forumsFuzzyImage = aGSCoverImage;
			//[aGSCoverImage release];
		}
		if (!self.firstShowResourceArray) 
		{
			NSMutableArray *aNSMutableArray = [[NSMutableArray alloc] init];
			self.firstShowResourceArray = aNSMutableArray;
			//[aNSMutableArray release];
			
		}
		if (!self.allResourceArray) 
		{
			NSMutableArray *aNSMutableArray = [[NSMutableArray alloc] init];
			self.allResourceArray = aNSMutableArray;
			//[aNSMutableArray release];
		}
				
		
	}
	return self;
}


@end
