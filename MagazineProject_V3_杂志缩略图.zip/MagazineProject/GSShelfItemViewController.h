//
//  GSShelfItemViewController.h
//  GSMagazinePublish
//
//  Created by on 12-12-19.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"


@interface GSShelfItemViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *ibShelfItemLbl;
@property (weak, nonatomic) IBOutlet AsyncImageView *ibShelfImgView;

@end
