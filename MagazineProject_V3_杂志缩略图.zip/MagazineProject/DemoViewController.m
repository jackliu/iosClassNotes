//
//  DemoViewController.m
//  RESideMenuExample
//
//  Created by Roman Efimov on 6/14/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DemoViewController.h"
#import "SecondViewController.h"
#import "MYLAppDelegate.h"


#import "GDataXMLNode.h"
#import "GSReachability.h"
#import "GSShelfItemViewController.h"
#import "FileOperation.h"
#import "GSShelfItemInfo.h"
#import "GSAlert.h"
#import "ASIHTTPRequest.h"
#import "GSStoreMap.h"
#import "FTAnimation.h"
#import "HomeCell.h"
//#import "MagazineCrossViewController.h"
#import "GSMagazineMap.h"
//#import "MagazineCatalogViewController.h"
#define DISPATCH_QUEUE_BACKGROUND           "com.meijia.bgqueue"
#define BOOK_HEIGHT                         273  //194
#define BOOK_WIDTH                          205

#define BOOK_PADDING_TOP_PORTRAIT           10
#define BOOK_PADDING_LEFT_PORTRAIT          0
#define BOOK_DISTANCE_PORTRAIT              40

#define BOOK_PADDING_TOP_LANDSCAPE          38
#define BOOK_PADDING_LEFT_LANDSCAPE         36
#define BOOK_DISTANCE_LANDSCAPE             64

#define NUM_BOOK_PORTRAIT                   3
#define NUM_BOOK_LANDSCAPE                  6

#define NUM_EXTRA_SHELF                     4

#define HEIGHT_SHELF                        320
#define LISTFILENAME @"ListXml"  //XML文件

#define NOTIFICATION_RELOADSHELF    @"notification_reloadshelf"



@implementation DemoViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title  = @"PCHouse";
    self.view.backgroundColor = [UIColor colorWithWhite:0.902 alpha:1.000];
    [self.navigationController.navigationBar setTitleTextAttributes:@{UITextAttributeTextColor: [UIColor whiteColor]}];
    if ([self.navigationController.navigationBar respondsToSelector:@selector(setBarTintColor:)]) {
        [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
        [self.navigationController.navigationBar performSelector:@selector(setBarTintColor:) withObject:[UIColor blueColor]];
    } else {
        [self.navigationController.navigationBar setTintColor:[UIColor blueColor]];
    }
}

#ifdef __IPHONE_7_0
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
#endif


#pragma mark - UITableViewDataSource Delegate




#pragma mark - UITableViewDelegate Delegate








@end
