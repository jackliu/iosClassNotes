//
//  GSBookshelf.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSBookshelf.h"


@implementation GSBookshelf

/*
- (void)removePeriodical:(GSPeriodical *)periodical andYear:(NSString *)year {
	
}
*/

@end
