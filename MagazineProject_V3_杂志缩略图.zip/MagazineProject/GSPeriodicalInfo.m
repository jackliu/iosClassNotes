//
//  GSPeriodicalInfo.m
//  GSMagazinePublish
//
//  Created by on 12-12-24.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSPeriodicalInfo.h"

//@implementation GSPageInfo
//@synthesize name;
//@synthesize path;
//@end

@implementation GSTopicInfo

@synthesize name;
@synthesize thumbName;
@synthesize path;
@synthesize intro;
@synthesize pages;

-(id) init {
    self = [super init];
    
    if (self) {
        self.pages = [[NSMutableArray alloc] init];
    }
    
    return self;
}

@end

@implementation GSPeriodicalInfo

@synthesize cover_pageName;
@synthesize cover_thumbName;
@synthesize cover_contentPath;
@synthesize catalog_pageName;
@synthesize catalog_thumbName;
@synthesize catalog_contentPath;
@synthesize topics;

-(id) init {
    self = [super init];
    
    if (self) {
        self.topics = [[NSMutableArray alloc] init];
    }
    
    return self;
}

@end
