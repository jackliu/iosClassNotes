//
//  GSTopic.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSCoverImage.h"
#import "GDataXMLNode.h"
#import "GSForum.h"
#import "GSAudio.h"
#import "GSVideo.h"

#import "GSText.h"
#import "ZipArchive.h"
#import "FileOperation.h"


@interface GSTopic : NSObject {

	NSString	*category;	//类别
	NSString	*topicTitle;	//标题
	NSString	*info;	//简介
	float		contentheight;	//主题高度
	GSAudio		*topicAudio;	//音频
	GSCoverImage	*previewImage;	//目录中每个主题的预览图片
	NSMutableArray	*forumArray;	//版面数组
	GSBaseResource	*topicInfoFile;
	GSBaseResource	*topicZipResourse;	//下载的主题资源zip包

}

@property (nonatomic, copy) NSString		*category;
@property (nonatomic, copy) NSString		*topicTitle;
@property (nonatomic, copy) NSString		*info;
@property (nonatomic, assign) float			contentheight;
@property (nonatomic, strong) GSAudio		*topicAudio;	//音频

@property (nonatomic, strong) GSCoverImage		*previewImage;
@property (nonatomic, strong) NSMutableArray	*forumArray;
@property (nonatomic, strong) GSBaseResource	*topicInfoFile;
@property (nonatomic, strong) GSBaseResource	*topicZipResourse;

/**
 * @brief	通过版面索引号pageNum，得到当前的GSPage页面对象
 * @param	版面索引号
 * @return	当前的GSPage页面对象/nil
 * @note	pageIndex是指页面数组pageArray中的索引
 */
- (void)getCurrentPage:(int)pageIndex;

/**
 * @brief	解析Topic信息文件，得到杂志信息
 * @param	Topic信息文件绝对路径
 * @return	
 * @note	
 */
- (void)parseTopicInfoFile:(NSString *)topicInfoFilePath;


@end
