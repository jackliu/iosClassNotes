//
//  GSVideo.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-20.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSVideo.h"


@implementation GSVideo
@synthesize fullScreen, frame;

@end
