//
//  GSShelfItemViewController.m
//  GSMagazinePublish
//
//  Created by on 12-12-19.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSShelfItemViewController.h"

#import <QuartzCore/QuartzCore.h>

@interface GSShelfItemViewController ()

@end

@implementation GSShelfItemViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void) loadView {
    [super loadView];
    
    [[self.view layer] setShadowOffset:CGSizeMake(1, 1)];
    [[self.view layer] setShadowRadius:5];
    [[self.view layer] setShadowOpacity:1];
    [[self.view layer] setShadowColor:[UIColor blackColor].CGColor];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setIbShelfItemLbl:nil];
    [self setIbShelfImgView:nil];
    [super viewDidUnload];
}
@end
