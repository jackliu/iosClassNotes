//
//  GSContentScrollView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-6.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSContentScrollView : UIScrollView {

	NSMutableArray *subTopciScrollViews;
}

@property (nonatomic, strong) NSMutableArray *subTopciScrollViews;

@end
