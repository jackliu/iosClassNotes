//
//  GSForumsView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-6.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSForumsView.h"


@implementation GSForumsView
@synthesize forumsImageView, firstShowResourceArray, allResourceArray, downIcon;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		if (!self.forumsImageView)
		{
			UIImageView *imageView = [[UIImageView alloc] init];
			self.forumsImageView = imageView;
			//[imageView release];
			
			[self.forumsImageView setFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
			[self addSubview:self.forumsImageView];
		}
		
		if (!self.downIcon)
		{
			UIImageView *imageView = [[UIImageView alloc] init];
			self.downIcon = imageView;
			//[imageView release];
			
			self.downIcon.image = [UIImage imageNamed:@"down.png"];
			/*
			self.downIcon.animationImages = [NSArray arrayWithObjects:[UIImage imageNamed:@"down.png"],[UIImage imageNamed:@"down1.png"],nil];
			self.downIcon.animationRepeatCount = 30;
			self.downIcon.animationDuration = 0.5;
			 */
			[self.downIcon setFrame:CGRectMake(768-30, 1024-60, 27, 25)];
			[self addSubview:self.downIcon];
			self.downIcon.hidden = YES;
		}
		
		
		if (!self.firstShowResourceArray)
		{
			NSMutableArray *arr = [[NSMutableArray alloc] init];
			self.firstShowResourceArray = arr;
			//[arr release];
		}
		if (!self.allResourceArray)
		{
			NSMutableArray *arr = [[NSMutableArray alloc] init];
			self.allResourceArray = arr;
			//[arr release];
		}
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/



@end
