//
//  GSIndexDetailView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-3-7.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSIndexDetailView : UIView {

	UIImageView		*bgImageView;	//背景底图
	UIProgressView	*progressView;	//进度条
	UIImageView		*indexImageView;	//导航小图
	UILabel			*indexTitle;	//导航标题
}


@property (nonatomic, strong) IBOutlet UIImageView		*bgImageView;
@property (nonatomic, strong) IBOutlet UIProgressView	*progressView;
@property (nonatomic, strong) IBOutlet UIImageView		*indexImageView;
@property (nonatomic, strong) IBOutlet UILabel			*indexTitle;


@end
