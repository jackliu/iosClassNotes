//
//  GSBookstoreView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GSbaseBookTypeView.h"

@interface GSBookstoreView : GSbaseBookTypeView {
	
}


@end
