//
//  GSIndexDetailView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-3-7.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSIndexDetailView.h"


@implementation GSIndexDetailView
@synthesize bgImageView, progressView, indexImageView, indexTitle;

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/



@end
