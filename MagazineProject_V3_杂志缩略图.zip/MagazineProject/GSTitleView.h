//
//  TitleView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSTitleView : UIView {

	UIImageView *titleImageView;
	UIButton	*bookstoreBtn;
	UIButton	*bookshelfBtn;
	UIButton	*yearBtn;
}

@property (nonatomic, strong) IBOutlet UIImageView	*titleImageView;
@property (nonatomic, strong) IBOutlet UIButton		*bookstoreBtn;
@property (nonatomic, strong) IBOutlet UIButton		*bookshelfBtn;
@property (nonatomic, strong) IBOutlet UIButton		*yearBtn;

@end
