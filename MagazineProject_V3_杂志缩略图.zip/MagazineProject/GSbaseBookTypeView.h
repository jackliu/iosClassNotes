//
//  GSbaseBookTypeView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GSPeriodicalView.h"

@interface GSbaseBookTypeView : UIView {

	NSMutableArray *periodicalViewArray;	//书店/书架中的期刊视图数组
}

@property (nonatomic, strong) NSMutableArray *periodicalViewArray;

/**
 * @brief	创建期刊视图组，并把他们放到periodicalViewArray中
 * @param
 * @return　　
 * @note	periodicalViewArray要创建
 */
- (void)createPeriodicalView;



@end
