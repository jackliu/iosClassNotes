//
//  GSMyShelfView.h
//  GSMagazinePublish
//
//  Created by zheng jie on 12-12-23.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GSMyShelfView : UIView

@end
