//
//  GSImageWithText.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-13.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSImageViewWithText.h"


@implementation GSImageViewWithText
@synthesize textView;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		if (!self.textView)
		{
			UITextView *aTextView = [[UITextView alloc] init];
			self.textView = aTextView;
			self.textView.editable = NO;
			//[aTextView release];
		}
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/



@end
