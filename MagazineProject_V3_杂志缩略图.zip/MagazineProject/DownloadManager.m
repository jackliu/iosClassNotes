//
//  DownloadManager.m
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-7.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "DownloadManager.h"

@implementation DownloadManager

+(void) downloadResource:(NSString *) resPath {    
}

-(void) requestStarted {
    
}

-(void) requestFinished {
    
}

@end
