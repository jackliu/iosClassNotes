//
//  GSStoreMap.m
//  GSMagazinePublish
//
//  Created by zheng jie on 13-1-14.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//
//书店xml解析
#import "GSStoreMap.h"

#import "GDataXMLNode.h"
#import "GSShelfItemInfo.h"

@implementation GSStoreMap
@synthesize storeMap;
@synthesize selectedYears;
@synthesize magazinesInfoArr;

+ (GSStoreMap *)sharedInstance
{
    static GSStoreMap *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[GSStoreMap alloc] init];
    });
    return shared;
}


//书店xml解析
- (void)getStoreMapFromXmlSource:(NSURL *)xmlUrl
{
    NSData *xmlData = nil;
    xmlData = [NSData dataWithContentsOfURL:xmlUrl];
    self.storeMap = [[NSMutableArray alloc] init];
    self.magazinesInfoArr = [[NSMutableArray alloc] init];
    self.selectedYears = [[NSMutableArray alloc] init];
    self.magazinesDic = [[NSMutableDictionary alloc] init];
    __block NSString *suffix_year;
    
    GDataXMLDocument *doc = [[GDataXMLDocument alloc] initWithData:xmlData options:0 error:nil];
    
    GDataXMLElement *rootElement = [doc rootElement];
    NSArray *years = [rootElement elementsForName:@"year"];
    [years enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        GDataXMLElement *year = obj;
        suffix_year = [[year attributeForName:@"value"] stringValue];
        [self.selectedYears addObject:suffix_year];
        NSLog(@"selectedYears is %@",self.selectedYears);
        //记录每年的期刊
        NSMutableArray  *magazinesArray = [[NSMutableArray alloc] initWithCapacity:0];
        //Month
        NSArray *months = [year elementsForName:@"Month"];
        [months enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            //按月初始化书架对象
            GSShelfItemInfo *shelfInfo = [[GSShelfItemInfo alloc] init];
            GDataXMLElement *month = obj;
            shelfInfo.year = suffix_year;
            shelfInfo.month = [[[[month attributeForName:@"value"] stringValue] componentsSeparatedByString:@"."] objectAtIndex:1];
            //periodical
            GDataXMLElement *periodical = [[month elementsForName:@"Periodical"] objectAtIndex:0];
            shelfInfo.periodicalNumber = [periodical stringValue];
            
            //Title
            GDataXMLElement *title = [[month elementsForName:@"Title"] objectAtIndex:0];
            shelfInfo.title = [title stringValue];
            
            //Synopsis 简介
            GDataXMLElement *synopsis = [[month elementsForName:@"Synopsis"] objectAtIndex:0];
            shelfInfo.synopsis = [synopsis stringValue];
            
            //frontCover
            GDataXMLElement *frontCover = [[month elementsForName:@"FrontCover"] objectAtIndex:0];
            shelfInfo.imageName = [frontCover stringValue];
            
            //catalogCover
            GDataXMLElement *catalogCover = [[month elementsForName:@"CatalogCover"] objectAtIndex:0];
            shelfInfo.catalogImageName = [catalogCover stringValue];
            
            //Ppath
            GDataXMLElement *ppath = [[month elementsForName:@"Ppath"] objectAtIndex:0];
            shelfInfo.contentXmlPath = [ppath stringValue];
            
            //封面子标题
            shelfInfo.subTitle = [NSString stringWithFormat:@"%@年%@月第%@期",shelfInfo.year,shelfInfo.month, shelfInfo.periodicalNumber];
            //封面图片路径
            shelfInfo.imageUrl = [NSString stringWithFormat:@"%@/%@/%@%@/%@%@_%@/ThumbPackage/%@",kResouceDownloadURL,shelfInfo.year,shelfInfo.year,shelfInfo.month,shelfInfo.year,shelfInfo.month,shelfInfo.periodicalNumber,shelfInfo.imageName];
            //字典 按年分类  magazinesInfoArr 删除
            [magazinesArray addObject:shelfInfo];
            
        }];
        //每年后 add
        [self.magazinesDic setObject:magazinesArray forKey:suffix_year];
    }];
    //多个年份 按年排序
//    NSArray *keys = [self.magazinesDic allKeys];
//    NSArray *sortedArray = [keys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
//        return [obj1 compare:obj2 options:NSNumericSearch];
//    }];
   // NSDictionary *myDic = [self.magazinesDic objectForKey:[sortedArray objectAtIndex:0]];
    NSLog(@"magazinesInfoArr list:%@",self.magazinesDic);
}


@end
