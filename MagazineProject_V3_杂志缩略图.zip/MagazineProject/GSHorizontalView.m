//
//  GSHorizontalView.m
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-25.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSHorizontalView.h"
#import "GSVerticalView.h"

@implementation GSHorizontalView

@synthesize dataSource = _dataSource;
@synthesize currentIndexPath = _currentIndexPath;
@synthesize verticalNumber;
- (id) initWithFrame:(CGRect)frame
      withDataSource:(NSArray *) dataSource_
withCurrentIndexPath:(NSIndexPath *) indexPath_ {
    self = [super initWithFrame:frame];
    if (self) {
        _atpView = [[ATPagingView alloc] initWithFrame:frame];
        _atpView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"crossview_bg.png"]];
        _atpView.direction = ATPagingViewHorizontal;
        _atpView.delegate = self;
        self.dataSource = dataSource_;
        self.currentIndexPath = indexPath_;
        [_atpView setGapBetweenPages:0];
        /*
        NSLog(@"_atpaging frame is %f,%f",_atpView.frame.size.width,_atpView.size.height);
         */
        
        [_atpView reloadData];
        [self addSubview:_atpView];
        _atpView.currentPageIndex = self.currentIndexPath.section;
        //初始化的时候发送通知 ，但开始为0
        NSString *catalogStr = [NSString stringWithFormat:@"%d", _atpView.currentPageIndex];
        NSLog(@"catalogStr is %@",catalogStr);
        [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_REFRENSHLOCATION"
                                                            object:@{@"catalog" : catalogStr}];
        
        //延迟刷新子页面
        [self performSelector:@selector(moveTo) withObject:self afterDelay:0.1];
    }
    
    return self;
}

-(void) setCurrentIndexPath:(NSIndexPath *)currentIndexPath {
    _currentIndexPath = currentIndexPath;
    _atpView.currentPageIndex = self.currentIndexPath.section;
    [self moveTo];
}

-(void) moveTo {
    //根据row刷新子scroll的当前页
    GSVerticalView* verticalView =
    (GSVerticalView *)[_atpView viewForPageAtIndex:_atpView.currentPageIndex];
    verticalView.currentIndex = _currentIndexPath.row;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _atpView = [[ATPagingView alloc] initWithFrame:frame];
        _atpView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"crossview_bg.png"]];
        _atpView.direction = ATPagingViewHorizontal;
        _atpView.delegate = self;
        [_atpView setGapBetweenPages:0];
        [self addSubview:_atpView];
    }
    return self;
}

#pragma mark - atpagingview delegate

-(NSInteger) numberOfPagesInPagingView:(ATPagingView *) pagingView{
    NSLog(@"横向所有页面数：%d",self.dataSource.count);
    return self.dataSource.count;
}
//每次加载当前一页和后一页（横向），负责页面的显示
-(UIView *) viewForPageInPagingView:(ATPagingView *)pagingView atIndex:(NSInteger)index {
    GSVerticalView *verticalView = (GSVerticalView *)[pagingView dequeueReusablePage];
    if (verticalView) {
        [verticalView removeFromSuperview];
        verticalView = nil;
    }
    if (!verticalView) {
        verticalView = [[GSVerticalView alloc] initWithFrame:pagingView.frame];
    }
    NSLog(@"index is %d",index);
    NSArray *tempDataSource = [self.dataSource objectAtIndex:index];
    verticalView.dataSource = tempDataSource;
    //NSLog(@"verticalView.dataSource is %@,count is %d",verticalView.dataSource,[verticalView.dataSource count]);
    //横向的向下箭头判断, 最后一页没有箭头显示（-1）
//    if ([verticalNumber intValue] < [verticalView.dataSource count]) {
//        if (verticalNumber == nil) {
//            verticalNumber = [NSString stringWithFormat:@"%d",0];
//        }
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_REFRENSHLOCATION" object:@{@"page" : verticalNumber,@"pageCount":[NSString stringWithFormat:@"%d",[verticalView.dataSource count]]}];
//    }
    
    return verticalView;
}
//滑动的时候触发，再调用viewforpage
- (void)currentPageDidChangeInPagingView:(ATPagingView *)pagingView {
    NSString *catalogStr = [NSString stringWithFormat:@"%d", pagingView.currentPageIndex];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_REFRENSHLOCATION"
                                                        object:@{@"catalog" : catalogStr}];
    NSLog(@"catalogStr is %@",catalogStr);
    //左右翻页的时候，获得竖向页面的index, 默认为0,可以设置(后期）
    GSVerticalView* verticalView =
    (GSVerticalView *)[_atpView viewForPageAtIndex:_atpView.currentPageIndex];
    NSInteger vCurrentIndex = verticalView.atpView.currentPageIndex;
    NSLog(@"vCurrentIndex is %d ,count is %d",vCurrentIndex,[verticalView.dataSource count]);
    verticalNumber = [NSString stringWithFormat:@"%d", vCurrentIndex];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_REFRENSHLOCATION"
                                                        object:@{@"page" : verticalNumber,@"pageCount":[NSString stringWithFormat:@"%d",[verticalView.dataSource count]]}];
}


//重新加载上一页的以关闭所有的内容
- (void)pagingViewDidEndMoving:(ATPagingView *)pagingView {
    GSVerticalView *preVView = (GSVerticalView *)[pagingView viewForPageAtIndex:pagingView.previousPageIndex];
    UIWebView *webView = (UIWebView *)[preVView.atpView viewForPageAtIndex:preVView.atpView.currentPageIndex];
    [webView reload];
}



@end
