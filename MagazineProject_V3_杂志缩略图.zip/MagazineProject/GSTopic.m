//
//  GSTopic.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//
#define kPortraitNode @"portrait"
#define kContentheight @"contentheight"
#define kForumsNode @"forums"
#define kForumsTag @"forumsTag"
#define kFuzzyImage @"fuzzyImage"
#define kImage @"image"
#define kText @"text"
#define kLeft @"left"
#define kTop @"top"
#define kWidth @"width"
#define kHeight @"height"
#define kPath @"path"

#define kFontstyle @"fontstyle"
#define kFontsize @"fontsize"
#define kDefaultFontstyle @"Helvatica"
#define kFontColor @"color"
#define kBgcolor @"bgcolor"
#define kTextcontent @"txtcontent"
#define kColorMax 255

#define kTouchenable @"touchenable"
#define ktouchenableJude @"True"

#define kVideo @"video"
#define kVideoCycle @"cycle"
#define kVideoFullscreen @"fullscreen"
#define kVideoFullscreenJude @"True"

#define kVideoVideopath @"videopath"

#define kAudio @"audio"
#define kAudioCycle @"cycle"
#define kAudioAudiopath @"audiopath" 

#define kTopicAudio @"BackgroundMusic" 

#define kVideoAutoplay @"autoplay"
#define kVideoAutoplayJude @"True"

#import "GSTopic.h"


@implementation GSTopic
@synthesize category, topicTitle, info, previewImage,
forumArray, topicInfoFile, contentheight, topicZipResourse, topicAudio;


- (id)init {
	self = [super init];
	if (self) {
		if (!self.previewImage)
		{
			GSCoverImage *aGSImage = [[GSCoverImage alloc] init];
			self.previewImage = aGSImage;
			//[aGSImage release];
		}
		if (!self.forumArray) 
		{
			NSMutableArray *arr = [[NSMutableArray alloc] init];
			self.forumArray = arr;
			//[arr release];
		}
		if (!self.topicInfoFile)
		{
			GSBaseResource *file = [[GSBaseResource alloc] init];
			self.topicInfoFile = file;
			//[file release];
		}
		if (!self.topicZipResourse)
		{
			GSBaseResource *aGSBaseResource = [[GSBaseResource alloc] init];
			self.topicZipResourse = aGSBaseResource;
			//[aGSBaseResource release];
		}
		if (!self.topicAudio)
		{
			GSAudio *aGSAudio = [[GSAudio alloc] init];
			self.topicAudio = aGSAudio;
			//[aGSAudio release];
		}
	}
	return self;
}


- (void)getCurrentPage:(int)pageIndex {
	
}



- (void)parseTopicInfoFile:(NSString *)topicInfoFilePath {
		//已经解析了
	if (self.contentheight > 0)
	{
		
	}
		//未解析
	else 
	{
		if ([FileOperation fileExistsAtPath:topicInfoFilePath])
		{
			NSData *topicInfoData = [NSData dataWithContentsOfFile:topicInfoFilePath];
			NSError *error = nil;
			GDataXMLDocument *doc = [[GDataXMLDocument alloc] initWithData:topicInfoData error:&error];
			GDataXMLElement *topicElement = [doc rootElement];
			
			NSArray *orinterfaceArr = [topicElement elementsForName:kPortraitNode];
			if ([orinterfaceArr count] > 0) 
			{
				GDataXMLElement *orinterfaceElement = [orinterfaceArr objectAtIndex:0];
				NSString *aContentheight = [[orinterfaceElement attributeForName:kContentheight] stringValue];
				NSLog(@"\n-/--/-/-/-/-/-/-/contentheight:%@",aContentheight);
				self.contentheight = [aContentheight floatValue];
				
				NSString *topicAudioPath = [[orinterfaceElement attributeForName:kTopicAudio] stringValue];
				NSLog(@"topicAudioPath:%@",topicAudioPath);
				[self.topicAudio setResourePathAndDownloadURL:topicAudioPath];
				
				NSArray *forumsArr = [orinterfaceElement elementsForName:kForumsNode];
				for(int i=0;i<[forumsArr count];i++)
				{
					NSLog(@"forums:%d",i);
                    // ljj add judge beyond array
                    if (i >= [self.forumArray count]) {
                        NSLog(@"ERROR: beyond array max count");
                        break;
                    }
                    
					GSForum *aGSForum = [self.forumArray objectAtIndex:i];
					GDataXMLElement *forumsElement = [forumsArr objectAtIndex:i];
					NSString *fuzzyImage = [[forumsElement attributeForName:kFuzzyImage] stringValue];
					NSLog(@"fuzzyImage:%@",fuzzyImage);
					[aGSForum.forumsFuzzyImage setResourePathAndDownloadURL:fuzzyImage]; 
					NSArray *imageArr = [forumsElement elementsForName:kImage];
					for(int j=0;j<[imageArr count];j++)
					{
						GDataXMLElement *imageElement = [imageArr objectAtIndex:j];
						NSString *left = [[imageElement attributeForName:kLeft] stringValue];
						NSString *top = [[imageElement attributeForName:kTop] stringValue];
						NSString *width = [[imageElement attributeForName:kWidth] stringValue];
						NSString *height = [[imageElement attributeForName:kHeight] stringValue];
						NSString *path = [[imageElement attributeForName:kPath] stringValue];
						NSString *touchenable = [[imageElement attributeForName:kTouchenable] stringValue];
						
						GSImage *aGSImage = [[GSImage alloc]init];
						aGSImage.frame = CGRectMake([left intValue], ([top intValue] - (i*kFullScreenHeightOfIpad)), [width intValue], [height intValue]);
						[aGSImage setResourePathAndDownloadURL:path];
						
						
						NSLog(@"left:%@",left);
						NSLog(@"top:%d",([top intValue] - (i*kFullScreenHeightOfIpad)));
						NSLog(@"width:%@",width);
						NSLog(@"height:%@",height);
						NSLog(@"path:%@",path);
						NSLog(@"touchenable:%@",touchenable);
						
							//有点击的对象
						if (NSOrderedSame == [touchenable caseInsensitiveCompare:ktouchenableJude])
						{
							aGSImage.isFirstShow = YES;
							
							NSString *autoplay = [[imageElement attributeForName:kVideoAutoplay] stringValue];
							if (NSOrderedSame == [autoplay caseInsensitiveCompare:kVideoAutoplayJude])
							{
								aGSImage.autoplay = YES;
							}							
							NSArray *touchArr;
							touchArr= [imageElement elementsForName:kVideo];
							if ([touchArr count] > 0) 
							{
								GDataXMLElement *touchElement = [touchArr objectAtIndex:0];
									//NSString *cycle = [[touchElement attributeForName:kVideoCycle] stringValue];
								NSString *fullscreen = [[touchElement attributeForName:kVideoFullscreen] stringValue];
								NSString *videopath = [[touchElement attributeForName:kVideoVideopath] stringValue];
								
								NSString *videoleft = [[touchElement attributeForName:kLeft] stringValue];
								NSString *videotop = [[touchElement attributeForName:kTop] stringValue];
								NSString *videowidth = [[touchElement attributeForName:kWidth] stringValue];
								NSString *videoheight = [[touchElement attributeForName:kHeight] stringValue];
								NSLog(@"videoleft:%@",videoleft);
								NSLog(@"videotop:%d",([videotop intValue] - (i*kFullScreenHeightOfIpad)));
								NSLog(@"videowidth:%@",videowidth);
								NSLog(@"videoheight:%@",videoheight);
								NSLog(@"videopath:%@",videopath);
								
								GSVideo *aGSVideo = [[GSVideo alloc] init];
								if (NSOrderedSame == [fullscreen caseInsensitiveCompare:kVideoFullscreenJude])
								{
									aGSVideo.fullScreen = YES;
								}
								[aGSVideo setResourePathAndDownloadURL:videopath];
								aGSVideo.frame = CGRectMake([videoleft intValue], [videotop intValue] - (i*kFullScreenHeightOfIpad), [videowidth intValue], [videoheight intValue]);
								
								aGSImage.indicatorType = GSIndicatorVideo;
								aGSImage.touchObject = aGSVideo;
								
								//[aGSVideo release];
							}
							touchArr = [imageElement elementsForName:kAudio];
							if ([touchArr count] > 0) 
							{
								GDataXMLElement *touchElement = [touchArr objectAtIndex:0];
									//NSString *cycle = [[touchElement attributeForName:kAudioCycle] stringValue];
								NSString *audiopath = [[touchElement attributeForName:kAudioAudiopath] stringValue];
								
								GSAudio *aGSAudio = [[GSAudio alloc] init];
								[aGSAudio setResourePathAndDownloadURL:audiopath];
								
								aGSImage.indicatorType = GSIndicatorAudio;
								aGSImage.touchObject = aGSAudio;
								
								//[aGSAudio release];
								
							}
							touchArr = [imageElement elementsForName:kText];
							if ([touchArr count] > 0) 
							{
								GDataXMLElement *textElement = [touchArr objectAtIndex:0];
								NSString *left = [[textElement attributeForName:kLeft] stringValue];
								NSString *top = [[textElement attributeForName:kTop] stringValue];
								NSString *width = [[textElement attributeForName:kWidth] stringValue];
								NSString *height = [[textElement attributeForName:kHeight] stringValue];
								NSString *fontstyle = [[textElement attributeForName:kFontstyle] stringValue];
								fontstyle = kDefaultFontstyle;	//暂时用这种字体
								NSString *fontsize = [[textElement attributeForName:kFontsize] stringValue];
								NSString *fontColor = [[textElement attributeForName:kFontColor] stringValue];
								NSString *bgcolor = [[textElement attributeForName:kBgcolor] stringValue];
								NSString *textcontent = [[textElement attributeForName:kTextcontent] stringValue];
								NSLog(@"left:%@",left);
								NSLog(@"top:%@",top);

								NSLog(@"handle_top:%d",([top intValue] - (i*kFullScreenHeightOfIpad)));
								NSLog(@"width:%@",width);
								NSLog(@"height:%@",height);
								NSLog(@"fontstyle:%@",fontstyle);
								NSLog(@"fontsize:%@",fontsize);
								NSLog(@"fontColor:%@",fontColor);
								NSLog(@"bgcolor:%@",bgcolor);
								NSLog(@"textcontent:%@",textcontent);
								
								
								GSText *aGSText = [[GSText alloc]init];
								aGSText.frame = CGRectMake([left intValue], ([top intValue] - (i*kFullScreenHeightOfIpad)), [width intValue], [height intValue]);
								aGSText.textContent = textcontent;
								aGSText.fontSize = fontsize;
								aGSText.fontStyle = fontstyle;
								
								
								NSArray *bgColorArr = [bgcolor componentsSeparatedByString:@","];
								if ([bgColorArr count] == 3)
								{
									aGSText.bgColor = [UIColor colorWithRed:([[bgColorArr objectAtIndex:0] floatValue]/kColorMax) green:([[bgColorArr objectAtIndex:1] floatValue]/kColorMax) blue:([[bgColorArr objectAtIndex:2] floatValue]/kColorMax) alpha:1.0];
								}
								else 
								{
									aGSText.bgColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.6];
								}
								
								
								NSArray *fontColorArr = [fontColor componentsSeparatedByString:@","];
								if ([fontColorArr count] == 3)
								{
									aGSText.fontColor = [UIColor colorWithRed:([[fontColorArr objectAtIndex:0] floatValue]/kColorMax) green:([[fontColorArr objectAtIndex:1] floatValue]/kColorMax) blue:([[fontColorArr objectAtIndex:2] floatValue]/kColorMax) alpha:1.0];
								}
								else 
								{
									aGSText.fontColor = [UIColor whiteColor];
								}
								NSLog(@"aGSText.bgColor:%@",aGSText.bgColor);
								NSLog(@"aGSText.fontColor:%@",aGSText.fontColor);
								
								aGSImage.indicatorType = GSIndicatorText;
								aGSImage.touchObject = aGSText;
								
								//[aGSText release];
							}
							touchArr= [imageElement elementsForName:kImage];
                            NSLog(@"array is %@",touchArr);
							if ([touchArr count] > 0) 
							{
								GDataXMLElement *touchElement = [touchArr objectAtIndex:0];
								NSString *imagepath = [[touchElement attributeForName:kPath] stringValue];
								
								NSString *imageleft = [[touchElement attributeForName:kLeft] stringValue];
								NSString *imagetop = [[touchElement attributeForName:kTop] stringValue];
								NSString *imagewidth = [[touchElement attributeForName:kWidth] stringValue];
								NSString *imageheight = [[touchElement attributeForName:kHeight] stringValue];
								
								NSLog(@"imageleft:%@",imageleft);
								NSLog(@"imagetop:%d",([imagetop intValue] - (i*kFullScreenHeightOfIpad)));
								NSLog(@"imagewidth:%@",imagewidth);
								NSLog(@"imageheight:%@",imageheight);
								NSLog(@"imagepath:%@",imagepath);
								
								GSImage *tempGSImage = [[GSImage alloc] init];
								
								[tempGSImage setResourePathAndDownloadURL:imagepath];
								tempGSImage.frame = CGRectMake([imageleft intValue], [imagetop intValue] - (i*kFullScreenHeightOfIpad), [imagewidth intValue], [imageheight intValue]);
								
								aGSImage.indicatorType = GSIndicatorImage;
								aGSImage.touchObject = tempGSImage;
								
								//[tempGSImage release];
							}
						}
						[aGSForum.firstShowResourceArray addObject:aGSImage];
						//[aGSImage release];
					}
					
					/*
					 <text left="0" top="0" width="0" height="0" fontstyle="方正舒体" fontsize="6" color="255,255,255" bgcolor="255,255,255" appearstyle="0" disappearstyle="0" txtcontent="呀呀嘿~~~~嘿嘿呀" />
					 */
					NSArray *textArr = [forumsElement elementsForName:kText];
					for(int k=0;k<[textArr count];k++)
					{
						GDataXMLElement *textElement = [textArr objectAtIndex:k];
						NSString *left = [[textElement attributeForName:kLeft] stringValue];
						NSString *top = [[textElement attributeForName:kTop] stringValue];
						NSString *width = [[textElement attributeForName:kWidth] stringValue];
						NSString *height = [[textElement attributeForName:kHeight] stringValue];
						NSString *fontstyle = [[textElement attributeForName:kFontstyle] stringValue];
						fontstyle = kDefaultFontstyle;	//暂时用这种字体
						NSString *fontsize = [[textElement attributeForName:kFontsize] stringValue];
						NSString *fontColor = [[textElement attributeForName:kFontColor] stringValue];
						NSString *bgcolor = [[textElement attributeForName:kBgcolor] stringValue];
						NSString *textcontent = [[textElement attributeForName:kTextcontent] stringValue];
						
						NSLog(@"left:%@",left);
						NSLog(@"top:%@",top);
						
						NSLog(@"handle_top:%d",([top intValue] - (i*kFullScreenHeightOfIpad)));
						NSLog(@"width:%@",width);
						NSLog(@"height:%@",height);
						NSLog(@"fontstyle:%@",fontstyle);
						NSLog(@"fontsize:%@",fontsize);
						NSLog(@"fontColor:%@",fontColor);
						NSLog(@"bgcolor:%@",bgcolor);
						NSLog(@"textcontent:%@",textcontent);
						
						
						GSText *aGSText = [[GSText alloc]init];
						aGSText.frame = CGRectMake([left intValue], ([top intValue] - (i*kFullScreenHeightOfIpad)), [width intValue], [height intValue]);
						
						aGSText.textContent = textcontent;
						aGSText.fontSize = fontsize;
						aGSText.fontStyle = fontstyle;
						
						NSArray *bgColorArr = [bgcolor componentsSeparatedByString:@","];
						if ([bgColorArr count] == 3)
						{
							aGSText.bgColor = [UIColor colorWithRed:([[bgColorArr objectAtIndex:0] floatValue]/kColorMax) green:([[bgColorArr objectAtIndex:1] floatValue]/kColorMax) blue:([[bgColorArr objectAtIndex:2] floatValue]/kColorMax) alpha:1.0];
						}
						else 
						{
							aGSText.bgColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.6];
						}

						
						NSArray *fontColorArr = [fontColor componentsSeparatedByString:@","];
						if ([fontColorArr count] == 3)
						{
							aGSText.fontColor = [UIColor colorWithRed:([[fontColorArr objectAtIndex:0] floatValue]/kColorMax) green:([[fontColorArr objectAtIndex:1] floatValue]/kColorMax) blue:([[fontColorArr objectAtIndex:2] floatValue]/kColorMax) alpha:1.0];
						}
						else 
						{
							aGSText.fontColor = [UIColor whiteColor];
						}
						
						NSLog(@"aGSText.bgColor:%@",aGSText.bgColor);
						NSLog(@"aGSText.fontColor:%@",aGSText.fontColor);
						
						aGSText.isFirstShow = YES;
						
						[aGSForum.firstShowResourceArray addObject:aGSText];
						//[aGSText release];
						
					}
					
				}
				
			}
			
			//[doc release];
		}
	}

	
}


@end
