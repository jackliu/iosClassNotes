//
//  GSText.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-8.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GSText : NSObject {
		//基本属性
	NSString	*fontStyle;		//字体类型
	NSString	*fontSize;		//字体大小
	UIColor		*fontColor;		//字体颜色
	UIColor		*bgColor;		//背景色
	NSString	*textContent;	//文本内容
	CGRect		frame;			//文本位置
	BOOL		isFirstShow;	//是不是一级显示		暂时不用
		//二级显示使用
//	GSViewAnimationStyle	appearStyle;	//动画显示方式
//	GSViewAnimationStyle	disappearStyle;	//动画消失方式
	
}
@property (nonatomic, copy) NSString *fontStyle;
@property (nonatomic, copy) NSString *fontSize;
@property (nonatomic, strong) UIColor *fontColor;
@property (nonatomic, strong) UIColor *bgColor;
//@property (nonatomic, assign) GSViewAnimationStyle appearStyle;
//@property (nonatomic, assign) GSViewAnimationStyle disappearStyle;
@property (nonatomic, assign) CGRect		frame;

@property (nonatomic, copy) NSString *textContent;
@property (nonatomic) BOOL isFirstShow;

@end
