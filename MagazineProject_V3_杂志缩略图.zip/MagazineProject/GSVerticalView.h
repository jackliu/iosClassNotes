//
//  GSVerticalView.h
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-25.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "ATPagingView.h"
#import "MBProgressHUD.h"
@interface GSVerticalView : UIView <ATPagingViewDelegate, UIGestureRecognizerDelegate,MBProgressHUDDelegate> {
    @private
    ATPagingView *_atpView;
    
    int _currentIndex;
    NSArray *_dataSource;
    
    int _catalogIndex;
    
    NSString *htmlPath;
    MBProgressHUD *mbHud;
}

@property (assign, nonatomic) int currentIndex;
@property (strong, nonatomic) NSArray *dataSource;
@property (assign, nonatomic) int catalogIndex;
@property (strong, nonatomic) NSString *htmlPath;

@property (readonly, strong, nonatomic) ATPagingView *atpView;

//- (void) showLocation:(UIGestureRecognizer *)sender;
@end
