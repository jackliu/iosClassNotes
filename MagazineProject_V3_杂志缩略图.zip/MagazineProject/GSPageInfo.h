//
//  GSPageInfo.h
//  GSMagazinePublish
//
//  Created by zheng jie on 13-1-6.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GSPageInfo : NSObject

@property (strong, nonatomic) NSString *page_pageName;//主题页的名称
@property (strong, nonatomic) NSString *page_pagePath;//主题页的路径
@property (strong, nonatomic) NSString *page_topicIntro;//主题第一页简介
@property (strong, nonatomic) NSString *page_thumbName; //主题第一页缩略图

@end
