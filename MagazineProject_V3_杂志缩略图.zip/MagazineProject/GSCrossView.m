//
//  GSCrossView.m
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-25.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSCrossView.h"
#import "GSHorizontalView.h"

@implementation GSCrossView

@synthesize dataSource;
@synthesize currentIndexPath = _currentIndexPath;

- (id) initWithFrame:(CGRect) frame
      withDataSource:(NSArray *) dataSource_
withCurrentIndexPath:(NSIndexPath *) indexPath_
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        horizontalView =[[GSHorizontalView alloc] initWithFrame:frame
                                                 withDataSource:dataSource_
                                           withCurrentIndexPath:indexPath_];
        //        horizontalView.dataSource = dataSource_;
        //        self.currentIndexPath = indexPath_;
        [self addSubview:horizontalView];
    }
    return self;
}

-(void) setCurrentIndexPath:(NSIndexPath *)currentIndexPath {
    _currentIndexPath = currentIndexPath;
    horizontalView.currentIndexPath = self.currentIndexPath;
}

@end
