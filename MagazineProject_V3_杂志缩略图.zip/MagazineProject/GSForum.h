//
//  GSForum.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-6.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSCoverImage.h"

@interface GSForum : NSObject {

	GSCoverImage	*forumsFuzzyImage;	//缩略图对象
	NSMutableArray	*firstShowResourceArray;	//第一阶梯（直接显示）资源数组
	NSMutableArray	*allResourceArray;	//所有资源数组（仅仅是视图——text，image，用于点击时，）		暂时不用
	
}

@property (nonatomic, strong) GSCoverImage	*forumsFuzzyImage;	//缩略图对象
@property (nonatomic, strong) NSMutableArray	*firstShowResourceArray;	//第一阶梯（直接显示）资源数组
@property (nonatomic, strong) NSMutableArray	*allResourceArray;

- (id)init;

@end
