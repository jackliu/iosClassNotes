//
//  GSStoreMap.h
//  GSMagazinePublish
//
//  Created by zheng jie on 13-1-14.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GSStoreMap : NSObject

//书店Info
@property (nonatomic, strong) NSMutableArray *storeMap;
@property (nonatomic, strong) NSMutableArray *selectedYears; //解析出来的年份（切换年份用）
@property (strong, nonatomic) NSMutableArray *magazinesInfoArr;
@property (strong, nonatomic) NSMutableDictionary *magazinesDic;
+ (GSStoreMap *)sharedInstance;
//书架xml
- (void)getStoreMapFromXmlSource:(NSURL *)xmlUrl;

@end
