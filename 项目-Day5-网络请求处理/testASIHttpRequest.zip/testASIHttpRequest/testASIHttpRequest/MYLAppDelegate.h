//
//  MYLAppDelegate.h
//  testASIHttpRequest
//
//  Created by shangdejigou on 13-11-25.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MYLViewController;

@interface MYLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MYLViewController *viewController;

@end
