//
//  MYLViewController.h
//  testASIHttpRequest
//
//  Created by shangdejigou on 13-11-25.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <UIKit/UIKit.h>

//1 导入 ASIHttpRequest 框架
#import "ASIHTTPRequest.h"
//2 同时下载多个文件，请求队列
#import "ASINetworkQueue.h"

@interface MYLViewController : UIViewController
{
    //下载队列
    ASINetworkQueue *networkQueue;
	bool failed;  //是否下载完成的状态判断
	NSFileManager* fm;  //对下载文件的处理对象
}




//文件1
@property (strong, nonatomic) IBOutlet UILabel *lbl1;
//文件2
@property (strong, nonatomic) IBOutlet UILabel *lbl2;
//总进度
@property (strong, nonatomic) IBOutlet UILabel *lbl3;

//进度条1
@property (strong, nonatomic) IBOutlet UIProgressView *prog1;
//进度条2
@property (strong, nonatomic) IBOutlet UIProgressView *prog2;
//进度条3
@property (strong, nonatomic) IBOutlet UIProgressView *prog3;



//发送同步请求获得服务器的 xml 数据
- (IBAction)request1:(UIButton *)sender;
//发送异步请求
- (IBAction)request2:(UIButton *)sender;
//文件下载
- (IBAction)zipDownload:(UIButton *)sender;

@end


