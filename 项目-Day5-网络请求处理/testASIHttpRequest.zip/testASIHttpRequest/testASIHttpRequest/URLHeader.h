//
//  URLHeader.h
//  testASIHttpRequest
//
//  Created by shangdejigou on 13-11-25.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#ifndef testASIHttpRequest_URLHeader_h
#define testASIHttpRequest_URLHeader_h


#define LISTXML_URL  @"http://192.168.1.4:8080/naill/upload/List.xml"

#define ZiPFILE_URL @"http://192.168.1.4:8080/naill/upload/2013/201311/201311_1/2013_11_1385362186169.zip"

#define IMAGE_URL @"http://images.apple.com/cn/iphone-5s/design/images/touchid_hero.png"

#endif
