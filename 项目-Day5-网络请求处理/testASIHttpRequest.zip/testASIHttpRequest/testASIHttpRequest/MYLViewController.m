//
//  MYLViewController.m
//  testASIHttpRequest
//
//  Created by shangdejigou on 13-11-25.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import "MYLViewController.h"

#import "URLHeader.h"

@interface MYLViewController ()

@end

@implementation MYLViewController

@synthesize lbl1,lbl2,lbl3,prog1,prog2,prog3;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 同步请求
- (IBAction)request1:(UIButton *)sender {
    //1 创建 url
    NSURL *url = [NSURL URLWithString:LISTXML_URL];
    //2 创建ASIHttpRequest 请求对象
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    //3 开始执行同步请求
    [request startSynchronous];
    
    //4 读取 响应数据Response
    //同步请求的特点：服务器一次性把所有数据都传过来
    int stausCode = [request responseStatusCode];
    switch (stausCode) {
        case 200:
            NSLog(@"服务器响应成功");
            break;
        case 404:
            NSLog(@"服务器没有找到你路径指定的东西");
            break;
        case 500:
            NSLog(@"服务器端出错");
            break;
            
        default:
            break;
    }
    
    NSString *responseStr = [request responseString];
    NSLog(@"服务器响应内容 :%@",responseStr);
}


#pragma mark - 发送异步请求
- (IBAction)request2:(UIButton *)sender {
    //使用代码块完成异步操作
    //1 创建 url
    NSURL *url = [NSURL URLWithString:LISTXML_URL];
    //2 创建ASIHttpRequest 请求对象
    __block ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    //3 开始执行异步请求
    //异步请求分为以下阶段:
    //(1)请求开始
    //(2)收到 HTTP 响应头信息
    //(3)请求结束
    //(4)请求失败
    //(5)失败后，重新连接，重新发送请求
    //(6)失败后，重新跳转到一个新的 URL--重定向
    
    //阶段(3)调用
    [request setCompletionBlock:^{
        NSString *responseStr = [request responseString];
        NSLog(@"服务器响应数据 \n  %@",responseStr);
    }];
    
    //阶段(4)调用
    [request setFailedBlock:^{
        NSError *error = [request error];
        NSLog(@"错误信息: %@",[error userInfo]);
    }];
    
    //异步请求，先准备好如何接受数据，最后启动
    [request startAsynchronous];

}


#pragma mark - 下载 zip 压缩包
- (IBAction)zipDownload:(UIButton *)sender {
    if (fm==nil) {
		fm=[NSFileManager defaultManager];
	}
    //得到沙箱路径
	NSString* userDocPath=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
	// 文件1
	NSString* file1= @"google.png";
	NSURL *url1 = [NSURL URLWithString:IMAGE_URL];
	// 先创建文件file1，再用 NSFileHandle 打开它
	NSString *path1=[userDocPath stringByAppendingPathComponent:file1];
	bool b=[fm createFileAtPath:path1 contents:nil attributes:nil];
	NSFileHandle *fh1;
	__block uint fSize1=0;															// 以 B 为单位，记录已下载的文件大小,需要声明为块可写
	if(b){
		fh1=[NSFileHandle fileHandleForWritingAtPath:path1];
	}
	
    // 文件2
	NSString* file2= @"aaa.zip";
	NSURL *url2 = [NSURL URLWithString:ZiPFILE_URL];
	// 先创建文件file2，再用 NSFileHandle 打开它
	NSString *path2=[userDocPath stringByAppendingPathComponent:file2];
	b=[fm createFileAtPath:path2 contents:nil attributes:nil];
	NSFileHandle *fh2;
	__block uint fSize2=0;															// 以 B 为单位，记录已下载的文件大小,需要声明为块可写
	if(b){
		fh2=[NSFileHandle fileHandleForWritingAtPath:path2];
	}
    
    //////////////////////////// 任务队列 /////////////////////////////
	if (!networkQueue) {
		networkQueue = [[ASINetworkQueue alloc] init];
	}
	failed = NO;
	// 队列清零
    [networkQueue reset];
    // 设置queue进度条
	[networkQueue setDownloadProgressDelegate:prog3];
    // 进度精确显示
	[networkQueue setShowAccurateProgress:YES];
    // 设置队列的代理对象
	[networkQueue setDelegate:self];
    
	ASIHTTPRequest *request;
	
	///////////////// request for file1 //////////////////////
	request = [ASIHTTPRequest requestWithURL:url1];
    // 设置文件1的url
	[request setDownloadProgressDelegate:prog1];
    // 文件1的下载进度条
	// 设置 userInfo，可用于识别不同的 request 对象
	[request setUserInfo:[NSDictionary dictionaryWithObject:file1 forKey:@"TargetPath"]];
	
	// 使用complete 块，在下载完时做一些事情
	[request setCompletionBlock:^(void){
		NSLog(@"%@ complete !",file1);
		assert(fh1);
		// 关闭 file1
		[fh1 closeFile];
	}];
	// 使用 failed 块，在下载失败时做一些事情
	[request setFailedBlock:^(void){
		NSLog(@"%@ download failed !",file1);}
	 ];
	
	
	// 使用 received 块，在接受到数据时做一些事情
	[request setDataReceivedBlock:^(NSData* data){
		fSize1+=data.length;
		[lbl1 setText:[NSString stringWithFormat:@"%.1f K",fSize1/1000.0]];
		[lbl3 setText:[NSString stringWithFormat:@"%.0f %%",prog3.progress*100]];
		if (fh1!=nil) {
			[fh1 seekToEndOfFile];
			[fh1 writeData:data];
		}
		NSLog(@"%@:%u",file1,data.length);
	}];
	
	[networkQueue addOperation:request];
	
	///////////// request for file2 //////////////////
    // 设置文件2的url
	request = [[ASIHTTPRequest alloc] initWithURL:url2];
    // 文件2的下载进度条
	[request setDownloadProgressDelegate:prog2];
	[request setUserInfo:[NSDictionary dictionaryWithObject:file2 forKey:@"TargetPath"]];
	
	// 使用complete 块，在下载完时做一些事情
	[request setCompletionBlock:^(void){
		NSLog(@"%@ complete !",file2);
		assert(fh2);
		// 关闭 file2
		[fh2 closeFile];
		
	}];
	// 使用 failed 块，在下载失败时做一些事情
	[request setFailedBlock:^(void){
		NSLog(@"%@ download failed !",file2);
	}];
	// 使用 received 块，在接受到数据时做一些事情
	[request setDataReceivedBlock:^(NSData* data){
		fSize2+=data.length;
		[lbl2 setText:[NSString stringWithFormat:@"%.1f K",fSize2/1000.0]];
		[lbl3 setText:[NSString stringWithFormat:@"%.0f %%",prog3.progress*100]];
		
		if (fh2!=nil) {
			[fh2 seekToEndOfFile];
			[fh2 writeData:data];
		}
	}];
	[networkQueue addOperation:request];
	[networkQueue go];		// 队列任务开始

}




@end






