This sample should automatically build and copy over the GData.framework as part of the build-and-run process.

NOTE: The Spreadsheet list and cell APIs will be replaced with the tables &
records API, as demonstrated in the SpreadsheetTableSample example application.

You should not use the list or cell feed APIs in new code.
