This sample should automatically build and copy over the GData.framework as part of the build-and-run process.
