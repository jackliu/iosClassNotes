This sample calls the GData Cocoa Touch support for OAuth. (iPhone, iPod Touch, iPad.)

Use the OAuthSampleTouch target if you have the iPhone SDK 3.2 or higher
(requires a Mac with Snow Leopard (OS X 10.6.YY).)

Use the OAuthSampleiPhone target if you have an earlier SDK, or are on a Mac
with Leopard (OS X 10.5.YY)

This sample uses a UINavigationController in its main view.

If your application's main view doesn't use UINavigationController, consider using your UIViewController's presentModalViewController: to push a new cover view that is a UINavigationController.


