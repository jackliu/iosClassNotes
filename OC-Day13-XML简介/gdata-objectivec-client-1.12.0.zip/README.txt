Information on using the Google Data APIs Objective-C Client Library 
is available at

http://code.google.com/p/gdata-objectivec-client/
