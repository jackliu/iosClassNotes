//
//  GSCatalogCell.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-2.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSCatalogCell : UITableViewCell {

	UIImageView	*previewImageView;
	UILabel		*categoryLabel;
	UILabel		*topicTitleLabel;
	UITextView	*infoLabel;
}

@property (nonatomic, strong) IBOutlet UIImageView	*previewImageView;
@property (nonatomic, strong) IBOutlet UILabel		*categoryLabel;
@property (nonatomic, strong) IBOutlet UILabel		*topicTitleLabel;
@property (nonatomic, strong) IBOutlet UITextView	*infoLabel;

@end
