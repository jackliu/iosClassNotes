//
//  GSShelfItemInfo.m
//  GSMagazinePublish
//
//  Created by  on 12-12-20.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSShelfItemInfo.h"
#import "FileOperation.h"

@implementation GSShelfItemInfo
@synthesize imageUrl;
@synthesize imageName;
@synthesize subTitle;
@synthesize contentXmlPath;
@synthesize title;
@synthesize synopsis;
@synthesize year,month,periodicalNumber;
@synthesize previewImageUrls;
@synthesize periodicalInfoFile;
@synthesize catalogImageName;
@synthesize magazineNumber;

-(void) getPreviewImageUrlsFromXml {
    
}
//设置每期的期刊号
- (void) setMagazineNumberFile:(NSString *)xmlFileName
{
    self.magazineNumber = [[[self.contentXmlPath lastPathComponent] componentsSeparatedByString:@"."] objectAtIndex:0];
    NSLog(@"magazineNumber %@",self.magazineNumber);
}
- (void) downShelfItemXmlIntoLocal:(NSString *)xmlRelativePath
{
    //获取本地期刊号.xml路径
    self.periodicalInfoFile = [[GSBaseResource alloc] init];
    /*
     // Caches/xmlname
     //根据书架中的杂志总201202_2012_03.xml，创建文件夹  caches/201202_2012_03/
     NSString *magazineFileName = [[NSString alloc] init];
     //获取每期的杂志文件名，unique
     magazineFileName = [[[[self.contentXmlPath componentsSeparatedByString:@"."] objectAtIndex:0] componentsSeparatedByString:@"/"] lastObject] ;
     NSLog(@"magazineFileName is %@",magazineFileName);
     */
    //[self setMagazineNumberFile:self.contentXmlPath]; //获取期刊号 controller中调用即可
    [self.periodicalInfoFile setMagazineResourePath:self.magazineNumber];
    // 下载绝对路径
    [self.periodicalInfoFile setXmlDownloadURL:xmlRelativePath];
    //是否存在当前期刊号的文件夹
    if (self.magazineNumber)
	{
		NSLog(@"self.PeriodicalInfoFile.downloadURL:%@",self.periodicalInfoFile.downloadURL);
		NSLog(@"self.PeriodicalInfoFile.resourePath:%@",self.periodicalInfoFile.resourePath);
        //资源使用目录 Library/Caches/magazineFileName];
		[FileOperation createDirectoryAtPath:[kCachesFolderPath stringByAppendingPathComponent:self.magazineNumber]];
        
		//只需下载对应xml文件即可，期号文件已经创建 /Caches/xmlname
		ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:self.periodicalInfoFile.downloadURL]];
		[request setDownloadDestinationPath:[self.periodicalInfoFile.resourePath stringByAppendingPathComponent:[self.magazineNumber stringByAppendingString:@".xml"]]];
		[request setDelegate:self];
		[request startAsynchronous];
		
		NSLog(@"request.downloadDestinationPath:%@",request.downloadDestinationPath);
		NSLog(@"request.url:%@",request.url);
		
		NSError *error = request.error;
        //文件下载完成
		if (!error)
		{
			NSLog(@"有网");
			//self.downloadStatus = NSDownload;
		}
        //文件下载错误
		else
		{
			//[ASIRequstErrorPutOut requstErrorCodePutOut:request];
			NSLog(@"断网");
            //			UIAlertView *offNetwork = [[UIAlertView alloc] initWithTitle:@"提示"
            //																 message:@"网络未连接，请检查网络."
            //																delegate:self
            //													   cancelButtonTitle:@"确定"
            //													   otherButtonTitles:nil];
            //			[offNetwork show];
		}
	}
	else
	{
		NSLog(@"已下载");
        
	}
    
}
- (void) downCoverThumbsIntoLocal:(NSString *)coverName getCoverDownloadURL:(NSString *)downloadImageURL
{
    //下载到某期刊号/....内 检查是否存在
    NSString *coverThumbsStr = [[NSString alloc] init];
    //    magazineNumber = [downloadImageURL lastPathComponent] componentsSeparatedByString:@".";
    //    downloadImageURL = [NSString stringWithFormat:@"%@/%@/%@",kResouceDownloadURL,magazineNumber,thumbsName];
    //获取本地路径 Caches/期刊号/缩略图名
    coverThumbsStr = [[FileOperation getCachesDirectory:self.magazineNumber] stringByAppendingPathComponent:coverName];
    NSLog(@"coverThumbsStr %@",coverThumbsStr);
    if (![FileOperation fileExistsAtPath:coverThumbsStr]) {
        //download
        // 下载绝对路径
        
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:downloadImageURL]];
		[request setDownloadDestinationPath:coverThumbsStr];
		[request setDelegate:self];
		[request startAsynchronous];
        NSLog(@"thumbs request.downloadDestinationPath:%@",request.downloadDestinationPath);
		NSLog(@"request.url:%@",request.url);
		
		NSError *error = request.error;
        //文件下载完成
		if (!error)
		{
			NSLog(@"有网");
			//self.downloadStatus = NSDownload;
		}
        //文件下载错误
		else
		{
			NSLog(@"断网");
        }
    }
//    if (![FileOperation fileExistsAtPath:catalogThumbsStr]) {
//        // 下载绝对路径
//        NSString *downloadCatalogURL = [[NSString alloc] init];
//        //使用stringByDeletingLastPathComponent方法会把http://变成http:/
//        downloadCatalogURL = [[[downloadImageURL stringByDeletingLastPathComponent] stringByAppendingPathComponent:catalogName] stringByReplacingOccurrencesOfString:@"http:/" withString:@"http://"];
//        ASIHTTPRequest *request2 = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:downloadCatalogURL]];
//		[request2 setDownloadDestinationPath:catalogThumbsStr];
//		[request2 setDelegate:self];
//		[request2 startSynchronous];
//        NSLog(@"thumbs2 request.downloadDestinationPath:%@",request2.downloadDestinationPath);
//		NSLog(@"request2.url:%@",request2.url);
//        NSError *error = request2.error;
//        //文件下载完成
//		if (!error)
//		{
//			NSLog(@"有网2");
//			//self.downloadStatus = NSDownload;
//		}
//        //文件下载错误
//		else
//		{
//			NSLog(@"断网");
//        }
//    }
//    else {
//        NSLog(@"已经下载2了");
//        
//    }
}


@end
