//
//  GSBaseBookshelf.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-17.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GSBaseBookshelf : NSObject {
	NSMutableDictionary *aGSPeriodicalDic;	//存放GSPeriodical（期刊对象）的数组,以及其对应的年份组成的字典
	NSString			*selectYear;	//选中的年份
}

@property (nonatomic, strong) NSMutableDictionary *aGSPeriodicalDic;
@property (nonatomic, copy) NSString *selectYear;

/**
 * @brief	通过"年份"得到一组期刊对象
 * @param	期刊年份
 * @return	一组期刊对象的数组/nil
 * @note	其中会判断年份是否存在
 */
- (NSArray *)getPeriodicalArrayForYear:(NSString *)year;

/**
 * @brief	初始化自身，创建aGSPeriodicalDic对象
 * @param	
 * @return	返回自身
 * @note	aGSPeriodicalDic对象要先判断有无。
 */
- (id)init;

@end
