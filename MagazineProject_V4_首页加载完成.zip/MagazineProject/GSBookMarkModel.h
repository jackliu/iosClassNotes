//
//  GSBookMarkModel.h
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 13-1-21.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GSBookMarkModel : NSObject

@property (strong, nonatomic) NSDate *bookmarkDate;
@property (strong, nonatomic) NSString *filePath;
@property (strong, nonatomic) NSIndexPath *indexPath;
@property (strong, nonatomic) NSString *mzTopic;

@end

@interface GSBookMarkManager : NSObject

+(GSBookMarkManager *) defaultManager;

-(NSArray *) fetchBookMarksWithUser:(NSString *) userName
                             mzName:(NSString *) mzName
                      periodicalNum:(NSString *) num;

-(void) addBookMarkWithUser:(NSString *) userName
                     mzName:(NSString *) mzName
              periodicalNum:(NSString *) num
              bookMarkModel:(GSBookMarkModel *) bookMarkModel;

-(void) removeBookMarkWithUser:(NSString *) userName
                        mzName:(NSString *) mzName
                 periodicalNum:(NSString *) num
                         index:(int) index;



@end
