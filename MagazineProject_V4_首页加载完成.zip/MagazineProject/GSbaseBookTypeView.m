//
//  GSbaseBookTypeView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#define kBookCount 24	//bookstoreView，bookshelfView的periodicalViewArray中的固定个数
	//PeriodicalView的坐标参数—— 中点
#define kPeriodicalViewInitX 150
#define kPeriodicalViewInitY 200
#define kPeriodicalViewDeltaX 243
#define kPeriodicalViewDeltaY 302
#define kPeriodicalViewCount 3	//PeriodicalView摆放时，每行的个数

#import "GSbaseBookTypeView.h"


@implementation GSbaseBookTypeView
@synthesize periodicalViewArray;


- (void)createPeriodicalView {
	if (!self.periodicalViewArray) 
	{
		NSMutableArray *aPeriodicalViewArray = [[NSMutableArray alloc] init];
		self.periodicalViewArray = aPeriodicalViewArray;
		//[aPeriodicalViewArray release];
	}
	
	for (int i=0; i<kBookCount; i++)
	{
		NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"GSPeriodicalView" owner:self options:nil];
		GSPeriodicalView *aGSPeriodicalView = [nibs objectAtIndex:0];
		aGSPeriodicalView.backgroundColor = [UIColor clearColor];
		aGSPeriodicalView.downloadstatus.backgroundColor = [UIColor clearColor];
		aGSPeriodicalView.periodicalImage.image = [UIImage imageNamed:@"coverDefault.png"];
		[aGSPeriodicalView setCenter:CGPointMake((kPeriodicalViewInitX + (kPeriodicalViewDeltaX*(i%kPeriodicalViewCount))), (kPeriodicalViewInitY + (kPeriodicalViewDeltaY*(i/kPeriodicalViewCount))))];
		aGSPeriodicalView.hidden = YES;
		[self.periodicalViewArray addObject:aGSPeriodicalView];
		[self addSubview:aGSPeriodicalView];
	}
}

@end
