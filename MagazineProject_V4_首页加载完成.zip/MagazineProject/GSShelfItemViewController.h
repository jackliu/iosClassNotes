//
//  GSShelfItemViewController.h
//  GSMagazinePublish
//
//  Created by on 12-12-19.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"

//主视图中，控制表格中一行内的 一个期刊的图片和文字描述的自定义视图
@interface GSShelfItemViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *ibShelfItemLbl;
@property (weak, nonatomic) IBOutlet AsyncImageView *ibShelfImgView;

@end
