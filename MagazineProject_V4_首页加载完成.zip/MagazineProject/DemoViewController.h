//
//  DemoViewController.h
//  RESideMenuExample
//
//  Created by Roman Efimov on 6/14/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"

@interface DemoViewController : RootViewController<UITableViewDataSource,UITableViewDelegate>
{
    UIActivityIndicatorView *_activity;
}

@property(nonatomic,strong)UITableView *tableView;


//定义界面需要的数据，存储的集合对象
@property (strong, nonatomic) NSMutableArray *magazines;
@property (strong, nonatomic) NSMutableArray *magazinesInfoArr;
@property (strong, nonatomic) NSMutableDictionary *selectedMagazineDic;  //已选择年份的数组
@property (strong, nonatomic) NSMutableArray *magazineArrYear;//按年份保存

@end






