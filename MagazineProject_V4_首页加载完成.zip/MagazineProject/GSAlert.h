//
//  GSAlert.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-3-15.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GSAlert : NSObject 
+ (void)showAlertWithTitle:(NSString *)title;
@end
