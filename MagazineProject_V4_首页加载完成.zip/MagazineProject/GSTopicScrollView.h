//
//  GSTopicScrollView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-9.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSTopicScrollView : UIScrollView {

	NSMutableArray *subForumViews;
}

@property (nonatomic, strong) NSMutableArray *subForumViews;

@end
