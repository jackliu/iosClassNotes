//
//  DLASIHTTPRequest.m
//  GSMagazinePublish
//
//  Created by on 12-12-4.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "DLASIHTTPRequest.h"
#import "FileOperation.h"

@implementation DLASIHTTPRequest
- (void)breakpointDownloadSetting:(NSString *)savePath andtempFolderPath:(NSString *)tempFolderPath {
	[self setAllowResumeForFileDownloads:YES];
	NSString *superDictory = [savePath stringByDeletingLastPathComponent];
	[FileOperation createDirectoryAtPath:superDictory];
	[self setDownloadDestinationPath:savePath];
    //设置临时文件目录
    //创建文件名（md5）
	NSString *AppendingFileName = @"";
	NSArray *path = [savePath componentsSeparatedByString:@"/"];
	for (int i = 0; i<[path count]; i++)
	{
		NSString *partPath = [path objectAtIndex:i];
		AppendingFileName = [AppendingFileName stringByAppendingString:partPath];
	}
	AppendingFileName = [self md5:AppendingFileName];
    //有无临时文件根目录，没有就创建
	[FileOperation createDirectoryAtPath:tempFolderPath];
    //文件名与临时文件根目录拼接成临时文件目录,用于写入
	NSString *tempPath = [tempFolderPath stringByAppendingPathComponent:AppendingFileName];
	[self setTemporaryFileDownloadPath:tempPath];
}

- (NSString *)md5:(NSString *)anAppendingFileName
{
    const char *cStr = [anAppendingFileName UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, strlen(cStr), result ); // This is the md5 call
    return [NSString stringWithFormat:
			@"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
			result[0], result[1], result[2], result[3],
			result[4], result[5], result[6], result[7],
			result[8], result[9], result[10], result[11],
			result[12], result[13], result[14], result[15]
			];
}
@end
