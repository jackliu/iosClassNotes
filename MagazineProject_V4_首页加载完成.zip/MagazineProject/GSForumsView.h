//
//  GSForumsView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-6.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSForumsView : UIView {

	UIImageView		*forumsImageView;	//缩略图视图
	NSMutableArray	*firstShowResourceArray;	//第一阶梯（直接显示）资源数组
	NSMutableArray	*allResourceArray;	//所有资源数组（仅仅是视图——text，image）
	UIImageView		*downIcon;	//下滑图标
}

@property (nonatomic, strong) UIImageView *forumsImageView;
@property (nonatomic, strong) UIImageView *downIcon;
@property (nonatomic, strong) NSMutableArray	*firstShowResourceArray;	//第一阶梯（直接显示）资源数组
@property (nonatomic, strong) NSMutableArray	*allResourceArray;	//所有资源数组

@end
