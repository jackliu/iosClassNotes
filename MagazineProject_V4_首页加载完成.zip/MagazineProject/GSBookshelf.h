//
//  GSBookshelf.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSBaseBookshelf.h"
//#import "GSPeriodical.h"

@interface GSBookshelf : GSBaseBookshelf {
	
}

/**
 * @brief	删除相应年份上的数组中的期刊
 * @param	期刊对象,期刊所属年份
 * @return	
 * @note	其中会判断年份是否存在
 
- (void)removePeriodical:(GSPeriodical *)periodical andYear:(NSString *)year;
*/
@end
