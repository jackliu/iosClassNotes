//
//  GSMyShelfView.m
//  GSMagazinePublish
//
//  Created by zheng jie on 12-12-23.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSMyShelfView.h"

@implementation GSMyShelfView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
//        UIImageView *shelfBackView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"myShelfBackground.png"]];
//        [self addSubview:shelfBackView];
//        [self bringSubviewToFront:shelfBackView];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
