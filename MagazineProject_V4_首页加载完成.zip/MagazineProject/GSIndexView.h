//
//  GSIndexView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-3-7.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GSIndexDetailView.h"

@interface GSIndexView : UIView {

	UIImageView		*bgImageview;
	UIScrollView	*indexDetailViewScroll;
	NSMutableArray	*indexDetailViewArray;
}

@property (nonatomic, strong) UIImageView	*bgImageview;
@property (nonatomic, strong) UIScrollView	*indexDetailViewScroll;
@property (nonatomic, strong) NSMutableArray	*indexDetailViewArray;

@end
