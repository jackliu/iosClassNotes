//
//  GSMagazine.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSBookshelf.h"
#import "GSBookstore.h"
#import "GSPeriodicalView.h"
#import "GSBaseResource.h"
#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"

@interface GSMagazine : NSObject {
	GSBookshelf *aGSBookshelf;	//书架
	GSBookstore *aGSBookstore;	//书店
	
	GSBaseResource *magazineInfoFile;	//杂志信息文件

	ASINetworkQueue *periodicalCoverQueue;	//主题zip组下载队列

}

@property (nonatomic, strong) GSBookshelf *aGSBookshelf;
@property (nonatomic, strong) GSBookstore *aGSBookstore;
@property (nonatomic, strong) GSBaseResource *magazineInfoFile;
@property (nonatomic, strong) ASINetworkQueue *periodicalCoverQueue;


/**
 * @brief	得到单例对象shareMagazine
 * @param
 * @return	GSMagazine单例对象shareMagazine
 * @note
 */
+ (id)shareGSMagazine;

/**
 * @brief	初始化shareMagazine，创建属性对象
 * @param
 * @return	GSMagazine单例对象shareMagazine
 * @note
 */
- (id)init;

/**
 * @brief	下载Magazine信息文件
 * @param
 * @return	
 * @note
 */
- (void)downloadMagazineInfoFile;

/**
 * @brief	解析Magazine信息文件，得到杂志信息
 * @param	Magazine信息文件绝对路径
 * @return	
 * @note
 */
- (void)parseMagazineInfoFile:(NSString *)magazineInfoFilePath;

/**
 * @brief	解析Magazine书架文件，得到书架信息
 * @param	Magazine书架文件绝对路径
 * @return	
 * @note
 */
- (void)parseShelfInfoFile:(NSString *)shelfInfoFilePath;

/**
 * @brief	开启队列,下载期刊的封面图片
 * @param	下载的期刊的年份，下载的期刊所属的对象（书店或书架）
 * @return	
 * @note
 */
- (void)downloadPeriodicalCover:(NSString *)yearStr bookType:(GSBaseBookshelf *)sender;

/**
 * @brief	结束期刊封面图片的下载
 * @param	
 * @return	
 * @note
 */
- (void)stopPeriodicalCoverQueue;

/**
 * @brief	期刊封面图片的下载队列中一个元素下载完成时的操作
 * @param	期刊封面图片的下载队列中一个元素
 * @return	
 * @note
 */
//- (void)periodicalCoverFetchComplete:(ASIHTTPRequest *)request;

/**
 * @brief	期刊封面图片的下载队列中一个元素下载失败时的操作
 * @param	期刊封面图片的下载队列中一个元素
 * @return	
 * @note
 */
//- (void)periodicalCoverFetchFailed:(ASIHTTPRequest *)request;

@end
