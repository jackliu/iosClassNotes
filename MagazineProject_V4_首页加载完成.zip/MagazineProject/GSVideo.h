//
//  GSVideo.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-20.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSBaseResource.h"

@interface GSVideo : GSBaseResource {
	BOOL fullScreen;	// 全屏播放
	CGRect frame;	//图片位置

}

@property (nonatomic, assign) BOOL fullScreen;
@property (nonatomic, assign) CGRect frame;

@end
