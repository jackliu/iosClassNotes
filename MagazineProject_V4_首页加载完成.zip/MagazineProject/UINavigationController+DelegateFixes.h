//
//  UINavigationController+DelegateFixes.h
//  Pinner
//
//  Created by Sam Oakley on 25/03/2013.
//  Copyright (c) 2013 Sam Oakley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (DelegateFixes)

@end
