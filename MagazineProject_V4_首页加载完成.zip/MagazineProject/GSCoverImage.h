//
//  GSImage.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-20.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSBaseResource.h"

@interface GSCoverImage : GSBaseResource {

}

@end
