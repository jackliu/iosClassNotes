//
//  DemoViewController.m
//  RESideMenuExample
//
//  Created by Roman Efimov on 6/14/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DemoViewController.h"
#import "SecondViewController.h"
#import "MYLAppDelegate.h"

#import "GDataXMLNode.h"
#import "GSReachability.h"
#import "GSShelfItemViewController.h"
#import "FileOperation.h"
#import "GSShelfItemInfo.h"
#import "GSAlert.h"
#import "ASIHTTPRequest.h"
#import "GSStoreMap.h"
#import "FTAnimation.h"
#import "HomeCell.h"
//#import "MagazineCrossViewController.h"
#import "GSMagazineMap.h"
//#import "MagazineCatalogViewController.h"
#define DISPATCH_QUEUE_BACKGROUND           "com.meijia.bgqueue"
#define BOOK_HEIGHT                         273  //194
//中间的间距
#define BOOK_WIDTH                          145

#define BOOK_PADDING_TOP_PORTRAIT           5
//左侧间距
#define BOOK_PADDING_LEFT_PORTRAIT          33
#define BOOK_DISTANCE_PORTRAIT              5

#define BOOK_PADDING_TOP_LANDSCAPE          38
#define BOOK_PADDING_LEFT_LANDSCAPE         36
#define BOOK_DISTANCE_LANDSCAPE             64

//竖屏，一行显示的期刊数目
#define NUM_BOOK_PORTRAIT                   2
//横屏，一行显示期刊数目
#define NUM_BOOK_LANDSCAPE                  4

#define NUM_EXTRA_SHELF                     4

//行高
#define HEIGHT_SHELF                        200

#define LISTFILENAME @"ListXml"  //XML文件

#define NOTIFICATION_RELOADSHELF    @"notification_reloadshelf"




@implementation DemoViewController

@synthesize magazineArrYear,magazines,selectedMagazineDic,magazinesInfoArr,tableView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //设置窗口样式
    self.title  = @"美甲杂志";
    self.view.backgroundColor = [UIColor colorWithWhite:0.902 alpha:1.000];
    [self.navigationController.navigationBar setTitleTextAttributes:@{UITextAttributeTextColor: [UIColor whiteColor]}];
    if ([self.navigationController.navigationBar respondsToSelector:@selector(setBarTintColor:)]) {
        [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
        [self.navigationController.navigationBar performSelector:@selector(setBarTintColor:) withObject:[UIColor blueColor]];
    } else {
        [self.navigationController.navigationBar setTintColor:[UIColor blueColor]];
    }
    
    //在窗口中添加表格对象
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    self.tableView.frame = self.view.bounds;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:tableView];
    
    
    //给集合对象，进行初始化
    self.magazines = [[NSMutableArray alloc] init];
    self.selectedMagazineDic = [[NSMutableDictionary alloc] init];
    self.magazinesInfoArr = [[NSMutableArray alloc] init];
    self.magazineArrYear = [[NSMutableArray alloc] init];
    
    //在首页界面加载完成后，调用后台访问的代码
    //最好使用多线程，新开一个线程访问
    //新建一个后台运行的线程队列
    dispatch_async(dispatch_queue_create(DISPATCH_QUEUE_BACKGROUND, NULL), ^{
        [self getListXML];
    });
}

#pragma mark - 自定义方法，获取后台的数据-List.xml
-(void)getListXML
{
    NSLog(@"------运行到这里，说明正在网络请求后台的 List.xml --------");
    //添加网络状态判断
    if ([GSReachability checkIfOnline]) {
        //网络正常链接
        //1 得到List.xml的路径
        NSURL *listURL = [NSURL URLWithString:KListXMLDownloadURL];
        //2 建立请求对象
        ASIHTTPRequest *request = [[ASIHTTPRequest alloc] initWithURL:listURL];
        //3 设置下载的路径
        [request setDownloadDestinationPath:[FileOperation getCachesDirectory:KListXMLName]];
        //使用缓存策略
        [request setCachePolicy:ASIUseDefaultCachePolicy];
        //GSSaveBundleFileInDocumentsDirectory(xmlData, LISTFILENAME);  //?每次保存的都是最新的list
        //解析对应路径的 XML ，得到首页需要的数据
        [[GSStoreMap sharedInstance] getStoreMapFromXmlSource:listURL];
    }
    else
    {
        //网络不能链接
        
    }
    

    //默认是所有杂志
    //{"2012":[杂志1,杂志2,杂志3,杂志4],"2013":[杂志1,杂志2,杂志3,杂志4]}
    [self.selectedMagazineDic addEntriesFromDictionary:[[GSStoreMap sharedInstance] magazinesDic]];
    
    //只得到年份
    [self.magazineArrYear addObjectsFromArray:[[GSStoreMap sharedInstance] selectedYears]];
    
    NSLog(@"测试得到所有的年份和杂志字典 selectedMagazineDic is %@",self.selectedMagazineDic);
    NSLog(@"测试得到所有的年份 magazineArrYear %@",magazineArrYear);
    
    //update tableview by main queue
    dispatch_async(dispatch_get_main_queue(), ^{
        [_activity stopAnimating];
        [self.tableView reloadData];
    });

}



#ifdef __IPHONE_7_0
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
#endif


#pragma mark - UITableViewDataSource Delegate
//得到章节数目--年
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.selectedMagazineDic count];
}

//得到每一年中，所有杂志的数目
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //解析总的字段对象,包含年，每年所有杂志的一个字段对象
    //{"2012":[杂志1,杂志2,杂志3,杂志4],"2013":[杂志1,杂志2,杂志3,杂志4]}
    // 字典对象中 key 是年份
    NSString *yearKey = [[self.selectedMagazineDic allKeys] objectAtIndex:section];
    // 字典对象中 value 是每年的所有期刊
    NSArray *maArray = [self.selectedMagazineDic objectForKey:yearKey];
    // 当前总的期刊数，但是表格中每行排两个期刊，所以行数要进行计算
    //如总共 2013 年总共有11 份期刊，每行排 2 份，那么就需要排6 行
    NSInteger magazinesCount = [maArray count];
    
    //num 就是表格中一个 section 中的 tableCell 行数
    NSInteger num = 0;
    if (magazinesCount == 0) {
        num = 1;
    }
    NSLog(@"ListBook: 本年度总的期刊数 = %i", magazinesCount);
    // Landscape横屏幕 一行显示 4 期
    if (GSIsLandSacpe(self.view)) {
        NSLog(@"ListBook:landscape");
        num = magazinesCount / NUM_BOOK_LANDSCAPE;
        if (magazinesCount % NUM_BOOK_LANDSCAPE != 0) {
            num++;
        }
    }
    // Portrait 竖屏,一行显示两个期刊
    else {
        NSLog(@"ListBook:portrait");
        num = magazinesCount / NUM_BOOK_PORTRAIT;
        if (magazinesCount % NUM_BOOK_PORTRAIT != 0) {
            num++;
        }
    }
    
    NSLog(@"ListBook: num row = %i", num);
    
    return num ;
}

//得到每行的单元格内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //分两个方向，这里我们只做纵向的
    static NSString *CellIdentifierPortrait = @"CellPortrait";
    
    UITableViewCell *cell = nil;
    
    __block float xPadding = 0;  //For block
    float topPadding = 0;
    float bookDistance = 0;
    NSInteger numBookPerShelf = 0;
    
    
    //LandScape
    if (GSIsLandSacpe(self.view)) {
        //横向，这里不做
    } else {
        //纵向
        //从表格中，取出一个现有的 tableCell 对象
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifierPortrait];
        if (cell == nil) {
            //如果取出的为空，说明目前没有 tableCell
            //所以这里创建一个自定义的 tableCell
            cell = [[HomeCell alloc] initWithStyle:UITableViewCellStyleDefault
                                   reuseIdentifier:CellIdentifierPortrait];
        }
        
        //一个 tableCell 中，要排两个期刊，期刊与期刊要进行定位
        //设置左边、顶部、的间隙，填充的像素大小
        xPadding = BOOK_PADDING_LEFT_PORTRAIT;
        topPadding = BOOK_PADDING_TOP_PORTRAIT;
        bookDistance = BOOK_DISTANCE_PORTRAIT;
        //设置一行显示期刊数 2 期
        numBookPerShelf = NUM_BOOK_PORTRAIT;
        
        [cell setBackgroundColor:[UIColor clearColor]];
    }
    
    //清除掉当前单元格中所有的子视图，方便后面代码添加新的子视图
    for (UIView *view in [cell.contentView subviews]) {
        [view removeFromSuperview];
    }
    
    NSInteger idStart = indexPath.row * numBookPerShelf;
    //得到当前一个 section 中的年份
    NSString *yearKey = [[self.selectedMagazineDic allKeys] objectAtIndex:indexPath.section];
    //取出当前 年份中的所有期刊
    NSArray *maArray = [self.selectedMagazineDic objectForKey:yearKey];
    
    ///////////////////////////////////////////////////////////////////
    //循环创建一行中的 两个 期刊的图片和描述文件
    for (NSInteger idMazagine = idStart;
         idMazagine < idStart + numBookPerShelf && idMazagine < [maArray count];
         idMazagine++) {
        //得到 dic ->>>shelfiteminfo
        //得到期刊对象
        GSShelfItemInfo *info = [maArray objectAtIndex:idMazagine];
        //创建期刊视图控制器对象
        GSShelfItemViewController *itemVC = [[GSShelfItemViewController alloc] initWithNibName:@"GSShelfItemViewController" bundle:nil];
        //设置一个子视图与周围的填充间距 padding
        [itemVC.view setOrigin:CGPointMake(xPadding, topPadding)];
        
        //用于TAP的时候查询是TAP了哪本书
        //itemVC.view.tag = idMazagine;
        //传递年-第几本 tag
        NSString *tapStr = [NSString stringWithFormat:@"%@%d",info.year,idMazagine];
        NSLog(@"现在点中了哪一本书 tapStr = is %@",tapStr);
        itemVC.view.tag = [tapStr intValue];
        
        ///////////////////////////////////////
        //取本地图片，如果没有则取网络图片
        NSString *imgUrl = @"";
        //设置每期的期刊号 一定要有
        [info setMagazineNumberFile:info.contentXmlPath];
        //从本地沙箱中读取缓存的图片路径
        NSString *cacheImgPath = [[FileOperation getCachesDirectory:info.magazineNumber] stringByAppendingPathComponent:info.imageName];
        // Library/Caches/201308_1/sfrontcover_1385835492.jpg
        // Library/Caches/201308_1/201308_1.xml
        if ([FileOperation fileExistsAtPath:cacheImgPath]) {
            imgUrl = cacheImgPath;
            NSLog(@"-----从本地取图片 imgUrl = %@",imgUrl);
            [itemVC.ibShelfImgView setImage:
             [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL fileURLWithPath:
                                                                   imgUrl]]]];
        } else {
            imgUrl = info.imageUrl;
            NSLog(@"-----从网络取图片 imgUrl = %@",imgUrl);
            [itemVC.ibShelfImgView setImageURL:[NSURL URLWithString:imgUrl]];
            
            //创建本地期刊目录 下载xml到本地对应期号文件夹内
            [info downShelfItemXmlIntoLocal:info.contentXmlPath];
            //下载本地封面缩略图到对应期刊号文件夹内
            [info downCoverThumbsIntoLocal:info.imageName getCoverDownloadURL:info.imageUrl];
        }
        NSLog(@"封面图片 cover image is %@, %@",info.imageName,info.imageUrl);
        //设置封面的描述文字
        [itemVC.ibShelfItemLbl setText:info.subTitle];
        
        //把自定义的一个 期刊封面视图，添加到单元格内
        [cell.contentView addSubview:itemVC.view];
        
        //调整填充间距，以便放入下一个期刊时，填充合理的间距
        xPadding += BOOK_WIDTH + bookDistance;
        
        
        NSLog(@"item x is %f,y is %f",itemVC.view.frame.origin.x,itemVC.view.frame.origin.y);
        
        //add tap action on item
        UITapGestureRecognizer *gester = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHandle:)];
        
        [itemVC.view addGestureRecognizer:gester];
        
    }
    ///////////////////////////////////////////////////////////////////
    
    //cell no select animation
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    //去掉grouped 边框
    UIView *tempView = [[UIView alloc] init];
    [cell setBackgroundView:tempView];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}


//添加章节头部的 section Header 上的 年份内容
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    //新建一个子视图，在子视图中可以设置的属性较多，实现的效果也更好
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectZero];
	UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
	titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:19.f];
	titleLabel.textColor = [UIColor blackColor];
	titleLabel.backgroundColor = [UIColor clearColor];
    
    NSString *yearKey = [[self.selectedMagazineDic allKeys] objectAtIndex:section];
    titleLabel.text = [NSString stringWithFormat:@"%@年",yearKey];
    titleLabel.frame = CGRectMake(15.f, 0.f, 80.f, 40.f);
	
    //把创建的子视图，添加到表格 section header 内部
	[headerView addSubview:titleLabel];
    headerView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"yearView.png"]];
	[headerView sizeToFit];
	return headerView;
}

//设置一个章节头部的高度，以便于放入一个自定义的 UIView 子视图
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 40.f;
}


-(float) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return HEIGHT_SHELF;
}



#pragma mark - UITableViewDelegate Delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //由于使用了自定义的 tableCell ，所以这里就不用编写代码，
    //所有的单元格事件，都由触摸手势完成 tapHandle:
}


//选中
-(void) tapHandle:(id) sender {
    UIGestureRecognizer *gester = (UIGestureRecognizer *) sender;
    UIView *v = gester.view;
    NSInteger index = v.tag;
    NSString *str = [NSString stringWithFormat:@"%d",index];
    NSLog(@" str is %@",str);
    //year
    NSString *str1 = [str substringToIndex:4];
    //tag
    NSString *str2 = [str substringFromIndex:4];
    NSLog(@"str1 is %@ %@",str1,str2);
    //第几年
    
    NSArray *maArray = [self.selectedMagazineDic objectForKey:str1];
    GSShelfItemInfo *info = [maArray objectAtIndex:[str2 intValue]];
    
    //获取每期的xml
    //解析本地xml，已下载了
    [info setMagazineNumberFile:info.contentXmlPath];//获得magazineNumber
    NSString *xmlPath = [[FileOperation getCachesDirectory:info.magazineNumber] stringByAppendingPathComponent:[info.contentXmlPath lastPathComponent]];
    GSMagazineMap *magazineMap = [[GSMagazineMap sharedInstance] init];
    [magazineMap getMapFromXmlSourece:[NSURL fileURLWithPath:xmlPath] getXmlNumber:info.magazineNumber];
    
    /*
    //直接跳转到浏览界面 先进去封面图片 下载好缩略图再进入
    //根据本地caches/201101_201101目录下的xml 来获取主题、页的关系，默认从首页封面下载
    // 获取每页的下载地址
    [[GSMagazineMap sharedInstance] downloadZipSource:info.magazineNumber];
    //解压每页
    //传递期刊号、主题页数，后期用户名
    NSLog(@"number is %@,title is %@ img url is %@",info.magazineNumber, info.title,info.imageUrl);
    MagazineCrossViewController *crollVC = [[MagazineCrossViewController alloc] initWithIndexPathRow:0 inSection:0 initWithMagazineNumber:info.magazineNumber withMagazineName:info.title withImageUrl:info.imageUrl];
    crollVC.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    //    [self presentModalViewController:crollVC animated:YES];
#warning ios5.0 above
    [self presentViewController:crollVC animated:YES completion:^{
        //        if (!self.view.hidden) {
        //            [self.view popOut:.1 delegate:nil];
        //        }
    }];
     */
}







@end
