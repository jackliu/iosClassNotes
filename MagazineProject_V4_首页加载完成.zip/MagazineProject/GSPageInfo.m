//
//  GSPageInfo.m
//  GSMagazinePublish
//
//  Created by zheng jie on 13-1-6.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//

#import "GSPageInfo.h"

@implementation GSPageInfo

@synthesize page_pageName;
@synthesize page_pagePath;
@synthesize page_topicIntro;
@synthesize page_thumbName;

@end
