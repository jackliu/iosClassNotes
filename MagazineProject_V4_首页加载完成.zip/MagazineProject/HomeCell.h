//
//  HomeCell.h
//  MeiJiaApp
//
//  Created by jimney on 13-11-17.
//  Copyright (c) 2013年 JieZheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCell : UITableViewCell

@end
