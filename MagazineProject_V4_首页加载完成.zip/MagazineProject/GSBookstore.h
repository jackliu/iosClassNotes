//
//  GSBookstore.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSBaseBookshelf.h"

@interface GSBookstore : GSBaseBookshelf {

}


@end
