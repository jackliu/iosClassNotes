//
//  GSBookshelfView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "GSbaseBookTypeView.h"


@interface GSBookshelfView : GSbaseBookTypeView {

	UIButton *editBtn;
	BOOL GSCanEdit;
}

@property (nonatomic, strong) IBOutlet UIButton *editBtn;

/**
 * @brief	点击“编辑”按钮，使得书架中的期刊编辑改变
 * @param	“编辑”按钮
 * @return	
 * @note	编辑状态有可删除，不可删除状态
 */
- (IBAction)editBtnClick:(id)sender;

@end
