//
//  GSMyShelfItemView.m
//  GSMagazinePublish
//
//  Created by zheng jie on 12-12-23.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSMyShelfItemView.h"

@implementation GSMyShelfItemView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
//        UIImageView *back = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DefaultBG.png"]];
//        [self addSubview:back];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
