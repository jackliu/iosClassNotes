//
//  GSPeriodicalView.h
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSPeriodicalView : UIView {
		//object
	UIImageView		*periodicalImage;	//期刊封面
	UILabel			*periodicalText;	//期刊标题
	UIButton		*removeBtn;			//删除按钮
	UILabel			*downloadstatus;	//记录期刊的下载状态
	UIProgressView	*progressView;		//进度条
		//base type
	CGSize		periodicalViewSize;
}

#pragma mark view
@property (nonatomic, strong) IBOutlet UIImageView	*periodicalImage;
@property (nonatomic, strong) IBOutlet UILabel		*periodicalText;
@property (nonatomic, strong) IBOutlet UIButton		*removeBtn;
@property (nonatomic, strong) IBOutlet UILabel		*downloadstatus;
@property (nonatomic, strong) IBOutlet UIProgressView	*progressView;	
#pragma mark data

@end
