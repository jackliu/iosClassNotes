//
//  GSPeriodical.m
//  MagazineProject
//
//  Created by shangdejigou on 13-11-29.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import "GSPeriodical.h"

@implementation GSPeriodical

@synthesize dateStr,numberStr,title,coverImage,periodicalInfoFile,periodicalResourse;

@end
