//
//  GSTopicScrollView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-9.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSTopicScrollView.h"


@implementation GSTopicScrollView
@synthesize subForumViews;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		if (!self.subForumViews)
		{
			NSMutableArray *arr = [[NSMutableArray alloc] init];
			self.subForumViews = arr;
			//[arr release];
		}
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/



@end
