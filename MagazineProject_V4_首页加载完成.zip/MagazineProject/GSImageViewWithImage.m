//
//  GSImageViewWithImage.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-13.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSImageViewWithImage.h"


@implementation GSImageViewWithImage
@synthesize imageView;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		if (!self.imageView) 
		{
			UIImageView *aUIImageView = [[UIImageView alloc] init];
			self.imageView = aUIImageView;
			//[aUIImageView release];
			

		}
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/



@end
