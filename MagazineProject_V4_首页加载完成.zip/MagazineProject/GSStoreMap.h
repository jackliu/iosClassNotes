//
//  GSStoreMap.h
//  GSMagazinePublish
//
//  Created by zheng jie on 13-1-14.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GSStoreMap : NSObject

//书店Info
@property (nonatomic, strong) NSMutableArray *storeMap;
//解析出来的年份（切换年份用）
//[2012,2013,2014]，显示在首页，表格的 sectionHeader 中
@property (nonatomic, strong) NSMutableArray *selectedYears;
//[杂志1,杂志2,杂志3,杂志4]
@property (strong, nonatomic) NSMutableArray *magazinesInfoArr;
//{"2012":[杂志1,杂志2,杂志3,杂志4],"2013":[杂志1,杂志2,杂志3,杂志4]}
@property (strong, nonatomic) NSMutableDictionary *magazinesDic;


+ (GSStoreMap *)sharedInstance;
//书架xml
- (void)getStoreMapFromXmlSource:(NSURL *)xmlUrl;

@end
