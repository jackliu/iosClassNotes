//
//  GSImage.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-20.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSCoverImage.h"


@implementation GSCoverImage

@end
