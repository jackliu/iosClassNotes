//
//  GSShelfItemInfo.h
//  GSMagazinePublish
//
//  Created by  on 12-12-20.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSBaseResource.h"
#import "ASIHTTPRequest.h"

@interface GSShelfItemInfo : NSObject<NSCoding>
{
    GSBaseResource *periodicalInfoFile;
}
@property (strong, nonatomic) NSString *imageUrl;          //封页图片URL
@property (strong, nonatomic) NSString *imageName;      //封页图片名
@property (strong, nonatomic) NSString *catalogImageName; //目录图片名
@property (strong, nonatomic) NSString *subTitle;       //期刊日期
@property (strong, nonatomic) NSString *contentXmlPath;    //期刊XML
@property (strong, nonatomic) NSString *title;          //期刊标题
@property (strong, nonatomic) NSString *periodicalNumber;      //期刊期号
@property (strong, nonatomic) NSString *synopsis;       //期刊概要
@property (strong, nonatomic) NSString *month;          //期刊月份
@property (strong, nonatomic) NSString *year;           //期刊年份(For Year search)
@property (strong, nonatomic) NSMutableArray *previewImageUrls;    //预览图
@property (strong, nonatomic) GSBaseResource	*periodicalInfoFile;
@property (strong, nonatomic) NSString *magazineNumber; //期刊号

- (void) getPreviewImageUrlsFromXml;
//创建本地文件目录 用来存放每期的xml和下载解压后的文件
- (void) createShelfItemFileInLocal;

- (void) setMagazineNumberFile:(NSString *)xmlFileName;
//根据创建的每个期号目录，下载到指定的期号文件夹中
- (void) downShelfItemXmlIntoLocal:(NSString *)xmlRelativePath;
//下载封面和目录的缩略图到本地对应期号内
- (void) downCoverThumbsIntoLocal:(NSString *)coverName getCoverDownloadURL:(NSString *)downloadImageURL;
@end
