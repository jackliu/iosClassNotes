//
//  GSBookshelfView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSBookshelfView.h"


@implementation GSBookshelfView
@synthesize editBtn;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
    }
    return self;
}


- (IBAction)editBtnClick:(id)sender {
	if (GSCanEdit) 
	{
		GSCanEdit = NO;
	}
	else //if (editType == GSCanEdit)
	{
		GSCanEdit = YES;
	}
	
	for (int i=0; i<[self.periodicalViewArray count]; i++)
	{
		GSPeriodicalView *aGSPeriodicalView = [self.periodicalViewArray objectAtIndex:i];
		aGSPeriodicalView.removeBtn.hidden = !GSCanEdit;
	}

}


@end
