//
//  GSMagazine.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-12.
//  Copyright 2012 Glavesoft. All rights reserved.
//

/*****
 Change: + (id)shareGSMagazine
        修改单例方法以使其符合 ARC特性。之后的单例都要符合这个格式
*/

#define kyearElement @"magazine"
#define kYearNode @"year"
#define kMonthNode @"Month"
#define kYearAttribute @"value"
#define kMonthAttribute @"value"
#define kPeriodicalNode @"Periodical"
#define kTitleNode @"Title"
#define kFrontCoverNode @"FrontCover"
#define kCatalogCoverNode @"CatalogCover"
#define kPpathNode @"Ppath"
#define kPeriodicalResourse @"PeriodicalResourse"

#import "GSMagazine.h"
#import "GDataXMLNode.h"
#import "GSPeriodical.h"
//#import "GSTopic.h"
#import "MeiJiaHeader.h"

#import "DLASIHTTPRequest.h"


@interface GSMagazine (hidden)
/**
 * @brief	判断期刊zip包资源下载队列是否下载成功
 * @param	期刊zip包资源下载队列
 * @return	YES：下载成功。NO：下载失败
 * @note	
 */
- (BOOL)isResourseQueueDownloadSuccess:(ASINetworkQueue *)networkQueue;
@end

__strong static GSMagazine *shareMagazine = nil;
@implementation GSMagazine
@synthesize aGSBookshelf,aGSBookstore,magazineInfoFile, periodicalCoverQueue;

#pragma mark -
#pragma mark shareGSMagazine
+ (id)shareGSMagazine
{
    //dispatch_once 参见：
    /*!
     * @function dispatch_once
     *
     * @abstract
     * Execute a block once and only once.
     *
     * @param predicate
     * A pointer to a dispatch_once_t that is used to test whether the block has
     * completed or not.
     *
     * @param block
     * The block to execute once.
     *
     * @discussion
     * Always call dispatch_once() before using or testing any variables that are
     * initialized by the block.
     */
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareMagazine = [[self alloc] init];
    });
    
    return shareMagazine;
 
    /*
	@synchronized(self) {
		if (shareMagazine) {
			return shareMagazine;
		}
        
		return shareMagazine = [[GSMagazine alloc] init];;
	}*/

}

- (id)init {
	self = [super init];
	if (self)
	{
		if (!self.magazineInfoFile)
		{
			GSBaseResource *file = [[GSBaseResource alloc] init];
			self.magazineInfoFile = file;
            /*
			[self.magazineInfoFile setResourePathAndDownloadURL:kListFolderName];
             */
		}
		
		if (!self.aGSBookshelf)
		{
			GSBookshelf *tempGSBookshelf = [[GSBookshelf alloc] init];	//aGSBookshelf中的aGSPeriodicalDic中的数组中的GSPeriodical是从aGSBookstore中retain过来的。
			self.aGSBookshelf = tempGSBookshelf;
		}
		if (!self.aGSBookstore)
		{
			GSBookstore *tempGSBookstore = [[GSBookstore alloc] init];
			self.aGSBookstore = tempGSBookstore;
		}
		if (!self.periodicalCoverQueue)
		{
			ASINetworkQueue *tempASINetworkQueue = [[ASINetworkQueue alloc] init];
			self.periodicalCoverQueue = tempASINetworkQueue;			
		}
		
	}
	return self;
}

#pragma mark -
#pragma mark MagazineInfoFile

- (void)downloadMagazineInfoFile {
	[FileOperation createDirectoryAtPath:kResouceUseFolderPath];
	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:self.magazineInfoFile.downloadURL]];
    
	[request setDownloadDestinationPath:self.magazineInfoFile.resourePath];
	[request setDelegate:self];
	[request startSynchronous];
	
	NSError *error = request.error;
		//文件下载完成
	if (!error) 
	{
		NSLog(@"有网");
	}
		//文件下载错误
	else 
	{
//		[ASIRequstErrorPutOut requstErrorCodePutOut:request];
		NSLog(@"断网");
		UIAlertView *offNetwork = [[UIAlertView alloc] initWithTitle:@"提示"
															 message:@"网络未连接，请检查网络." 
															delegate:self
												   cancelButtonTitle:@"确定" 
												   otherButtonTitles:nil];
		[offNetwork show];
	}
}

//重新解析下载后的list.xml总的xml文件，对照最新的xml格式修改解析

- (void)parseMagazineInfoFile:(NSString *)magazineInfoFilePath {
	if ([FileOperation fileExistsAtPath:magazineInfoFilePath]) 
	{
		NSData *magazineInfoData = [NSData dataWithContentsOfFile:magazineInfoFilePath];
		NSError *error = nil;
		GDataXMLDocument *doc = [[GDataXMLDocument alloc] initWithData:magazineInfoData options:1 error:&error];
		GDataXMLElement *magazineElement = [doc rootElement];
		NSArray *yearArr = [magazineElement elementsForName:kYearNode];
		
		
		for (int i=0; i<[yearArr count]; i++)
		{
			GDataXMLElement *yearElement = [yearArr objectAtIndex:i];
			NSArray *monthArr = [yearElement elementsForName:kMonthNode];
			NSString *year = [[yearElement attributeForName:kYearAttribute] stringValue];
			NSLog(@"year:%@",year);
			if (i == 0)
			{
				aGSBookstore.selectYear = year;
			}
			NSMutableArray *aGSPeriodicalArray = [[NSMutableArray alloc] init];
			for (int j=0; j<[monthArr count]; j++)
			{
				GSPeriodical *aGSPeriodical = [[GSPeriodical alloc] init];
					//<Month value="2012.01">
				GDataXMLElement *mouthElement = [monthArr objectAtIndex:j];
				NSString *month = [[mouthElement attributeForName:kMonthAttribute] stringValue];
				NSLog(@"month:%@",month);
				aGSPeriodical.dateStr = month;
					//<Periodical>201201</Periodical>
				NSArray *periodicalArr = [mouthElement elementsForName:kPeriodicalNode];
				if ([periodicalArr count] > 0)
				{
					GDataXMLElement *periodicalElement = [periodicalArr objectAtIndex:0];
					NSString *periodical = [periodicalElement stringValue];
					NSLog(@"periodical = %@", periodical);
					aGSPeriodical.numberStr = periodical;
				}
					//<WholePeriodical>201201</WholePeriodical>
				NSArray *titleArr = [mouthElement elementsForName:kTitleNode];
				if ([titleArr count] > 0)
				{
					NSString *title = [(GDataXMLElement *)[titleArr objectAtIndex:0] stringValue];
					NSLog(@"title = %@", title);
					aGSPeriodical.title = title;
				}
					//<FrontCover>2012/201201/009.jpg</FrontCover>
				NSArray *frontCoverArr = [mouthElement elementsForName:kFrontCoverNode];
				if ([frontCoverArr count] > 0)
				{
					NSString *frontCover = [(GDataXMLElement *)[frontCoverArr objectAtIndex:0] stringValue];
					NSLog(@"frontCover = %@", frontCover);
					
                    /*
					[aGSPeriodical.coverImage setResourePathAndDownloadURL:frontCover];
                     */
				}
					//<CatalogCover>2012/201201/009.jpg</CatalogCover>
				NSArray *catalogCoverArr = [mouthElement elementsForName:kCatalogCoverNode];
				if ([catalogCoverArr count] > 0)
				{
					NSString *catalogCover = [(GDataXMLElement *)[catalogCoverArr objectAtIndex:0] stringValue];
					NSLog(@"CatalogCover = %@", catalogCover);
				}
				/*
				NSArray *periodicalResourseArr = [mouthElement elementsForName:kPeriodicalResourse];
				if ([periodicalResourseArr count] > 0)
				{
					NSString *periodicalResourse = [(GDataXMLElement *)[periodicalResourseArr objectAtIndex:0] stringValue];
					NSLog(@"periodicalResourse = %@", periodicalResourse);
					[aGSPeriodical.periodicalResourse setResourePathAndDownloadURL:periodicalResourse];
				}
				 */
				//<Ppath>2012/201201/201201.xml</Ppath>
				NSArray *ppathArr = [mouthElement elementsForName:kPpathNode];
				if ([ppathArr count] > 0)
				{
					NSString *ppath = [(GDataXMLElement *)[ppathArr objectAtIndex:0] stringValue];
					NSLog(@"ppath = %@", ppath);
                    /*
					[aGSPeriodical.periodicalInfoFile setResourePathAndDownloadURL:ppath];
                     */
				}
				
				[aGSPeriodicalArray addObject:aGSPeriodical];
			}
			
			[self.aGSBookstore.aGSPeriodicalDic setObject:aGSPeriodicalArray forKey:year];
		}
	}
}

- (void)parseShelfInfoFile:(NSString *)shelfInfoFilePath {
	
	for (NSString *selectYear in [self.aGSBookstore.aGSPeriodicalDic allKeys])
	{		
		NSArray *arr = (NSArray *)[self.aGSBookstore.aGSPeriodicalDic objectForKey:selectYear];
		
		NSMutableArray *aGSPeriodicalArray = [[NSMutableArray alloc] init];
        
        //在之后可以使用Block来优化代码
        [arr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            GSPeriodical *aGSPeriodical = (GSPeriodical *) obj;
			id year = [[NSUserDefaults standardUserDefaults] objectForKey:aGSPeriodical.dateStr];
			
			if (year)
			{
				[aGSPeriodicalArray addObject:aGSPeriodical];
			}
        }];
        
        /*
		for (int i = 0; i<[arr count]; i++)
		{
			GSPeriodical *aGSPeriodical = [arr objectAtIndex:i];
			id year = [[NSUserDefaults standardUserDefaults] objectForKey:aGSPeriodical.dateStr];
			
			if (year) 
			{
				[aGSPeriodicalArray addObject:aGSPeriodical];
			}
		}*/
		
		if ([aGSPeriodicalArray count] > 0)
		{
			[self.aGSBookshelf.aGSPeriodicalDic setObject:aGSPeriodicalArray forKey:selectYear];
		}

	}
	
}

#pragma mark download----------------
- (void)downloadPeriodicalCover:(NSString *)yearStr bookType:(GSBaseBookshelf *)sender {
	
	[self stopPeriodicalCoverQueue];
	[self.periodicalCoverQueue setRequestDidFinishSelector:@selector(periodicalCoverFetchComplete:)];
	[self.periodicalCoverQueue setRequestDidFailSelector:@selector(periodicalCoverFetchFailed:)];
	[self.periodicalCoverQueue setShowAccurateProgress:YES];
	[self.periodicalCoverQueue setDelegate:self];
	
	NSArray *aGSPeriodicalArray = [sender getPeriodicalArrayForYear:yearStr];
	for (int i = 0; i < [aGSPeriodicalArray count]; i++)
	{
		GSPeriodical *aGSPeriodical = [aGSPeriodicalArray objectAtIndex:i];
		NSString *savePath = aGSPeriodical.coverImage.resourePath;
		NSLog(@"savePath:%@",savePath);
		if (![FileOperation fileExistsAtPath:savePath])
		{
			DLASIHTTPRequest *request;
			request = [DLASIHTTPRequest requestWithURL:[NSURL URLWithString:aGSPeriodical.coverImage.downloadURL]];
				//支持断点下载
			NSLog(@"kTmpFolderPath:%@",kTmpFolderPath);
			[request breakpointDownloadSetting:savePath andtempFolderPath:kTmpFolderPath];
			
            /*
			NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:i],kUserInfoKey,nil];
			
			[request setUserInfo:userInfo];
			*/
			[self.periodicalCoverQueue addOperation:request];
		}
	}
	
	if ([self.periodicalCoverQueue operationCount] != 0)
	{
		[self.periodicalCoverQueue setMaxConcurrentOperationCount:3];
		[self.periodicalCoverQueue go];
	}
}

- (void)stopPeriodicalCoverQueue {
	[self.periodicalCoverQueue reset];

}

- (void)periodicalCoverFetchComplete:(ASIHTTPRequest *)request {
    /*
	[[NSNotificationCenter defaultCenter] postNotificationName:kPeriodicalCoverFetchComplete object:request];
     */
}

	//下载错误
- (void)periodicalCoverFetchFailed:(ASIHTTPRequest *)request {	
}

@end
