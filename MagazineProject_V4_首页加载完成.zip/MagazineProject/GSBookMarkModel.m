//
//  GSBookMarkModel.m
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 13-1-21.
//  Copyright (c) 2013年 GlaveSoft. All rights reserved.
//

#import "GSBookMarkModel.h"
#import "GS_Util.h"
#import "FileOperation.h"

#define BOOKMARK_PLIST @"bookmark.plist"

@implementation GSBookMarkModel

@synthesize bookmarkDate;
@synthesize indexPath;
@synthesize filePath;

@end

@implementation GSBookMarkManager

+(GSBookMarkManager *) defaultManager {
    static GSBookMarkManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[GSBookMarkManager alloc] init];
    });
    
    return defaultManager;
}

-(NSString *) convertKeyToSHA1:(NSString *) userName
                        mzName:(NSString *) mzName
                 periodicalNum:(NSString *) num {
    NSString *keyStr = [NSString stringWithFormat:@"%@%@%@", userName, mzName, num];
    NSLog(@"key str is %@",keyStr);
    return [GS_Util SHA1:keyStr];
}

-(BOOL) favourated:(NSString *) userName
            mzName:(NSString *) mzName
     periodicalNum:(NSString *) num
         indexPath:(NSIndexPath *) indexPath {
    
    NSArray *modelsArr = [self fetchBookMarksWithUser:userName
                                               mzName:mzName
                                        periodicalNum:num];
    
    __block BOOL found = NO;
    [modelsArr enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        GSBookMarkModel *s_model = obj;
        int row = s_model.indexPath.row;
        int section = s_model.indexPath.section;
        NSIndexPath *tempIndexPath = [NSIndexPath indexPathForRow:row inSection:section];
        if ([tempIndexPath isEqual:indexPath]) {
            found = YES;
            *stop = YES;
        }
    }];
    
    return found;
}

-(NSArray *) fetchBookMarksArrWithUser:(NSString *) userName
                                mzName:(NSString *) mzName
                         periodicalNum:(NSString *) num {
    NSString *path = GSPathForFileInDocumentsDirectory(BOOKMARK_PLIST);
    NSDictionary *rootdic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSString *key = [self convertKeyToSHA1:userName mzName:mzName periodicalNum:num];
    NSArray *s_models = [rootdic objectForKey:key];
    NSMutableArray *t_models = [[NSMutableArray alloc] init];
    [s_models enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSDictionary *modelDic = obj;
        [t_models addObject:modelDic];
    }];
    
    return [t_models copy];
}

-(NSArray *) fetchBookMarksWithUser:(NSString *) userName
                             mzName:(NSString *) mzName
                      periodicalNum:(NSString *) num {
    NSString *path = GSPathForFileInDocumentsDirectory(BOOKMARK_PLIST);
    if (path.length == 0) {
        //创建plist
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *fileName = [documentsDirectory stringByAppendingPathComponent:BOOKMARK_PLIST];
//        NSFileManager *fileManager = [NSFileManager defaultManager];
//        [fileManager createFileAtPath:fileName contents:nil attributes:nil];
        NSDictionary *dic = [NSDictionary dictionary];
        [dic writeToFile:fileName atomically:YES];
    }
    //读取文件
    NSDictionary *rootdic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSString *key = [self convertKeyToSHA1:userName mzName:mzName periodicalNum:num];
    NSArray *s_models = [rootdic objectForKey:key];
    NSMutableArray *t_models = [[NSMutableArray alloc] init];
    [s_models enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSDictionary *modelDic = obj;
        GSBookMarkModel *model = [[GSBookMarkModel alloc] init];
        model.bookmarkDate = [modelDic objectForKey:@"bookmarkDate"];
        int section = [[modelDic objectForKey:@"section"] intValue];
        int row = [[modelDic objectForKey:@"row"] intValue];
        model.indexPath = [NSIndexPath indexPathForRow:row inSection:section];
        model.filePath = [modelDic objectForKey:@"filePath"];
        model.mzTopic = [modelDic objectForKey:@"mzTopic"];
        [t_models addObject:model];
    }];
    NSLog(@"t_models copy is %@",[t_models copy]);
    return [t_models copy];
}

-(void) addBookMarkWithUser:(NSString *) userName
                     mzName:(NSString *) mzName
              periodicalNum:(NSString *) num
              bookMarkModel:(GSBookMarkModel *) bookMarkModel {
    //存在该书签，返回
    if ([self favourated:userName mzName:mzName periodicalNum:num indexPath:bookMarkModel.indexPath]) {
        GS_Alert(@"已经存在！");
        return;
    }
    NSString *path = GSPathForFileInDocumentsDirectory(BOOKMARK_PLIST);
    if (path.length == 0) {
        //创建plist
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *fileName = [documentsDirectory stringByAppendingPathComponent:BOOKMARK_PLIST];
        //        NSFileManager *fileManager = [NSFileManager defaultManager];
        //        [fileManager createFileAtPath:fileName contents:nil attributes:nil];
        NSDictionary *dic = [NSDictionary dictionary];
        [dic writeToFile:fileName atomically:YES];
    }

    NSString *key = [self convertKeyToSHA1:userName mzName:mzName periodicalNum:num];
    NSString *filename=[GS_DOCUMENTS stringByAppendingPathComponent:BOOKMARK_PLIST];
    
    NSDictionary *modelDic = nil;
    modelDic = @{
    @"bookmarkDate" : bookMarkModel.bookmarkDate,
    @"section" : [NSString stringWithFormat:@"%d", bookMarkModel.indexPath.section],
    @"row" : [NSString stringWithFormat:@"%d", bookMarkModel.indexPath.row],
    @"filePath": bookMarkModel.filePath,
    @"mzTopic" :bookMarkModel.mzTopic
    };
    
    NSDictionary *rootDic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSArray *s_modelsArr = [rootDic objectForKey:key];
    NSMutableArray *t_modelsArr = nil;
    //只会执行if，初始化array
    if (!s_modelsArr) {
        t_modelsArr = [NSMutableArray array];
    } else {
        t_modelsArr = [s_modelsArr mutableCopy];
    }
    //array of dic
    [t_modelsArr addObject:modelDic];
    NSMutableDictionary *t_dic = [rootDic mutableCopy];
    [t_dic setObject:t_modelsArr forKey:key];
    [t_dic writeToFile:filename atomically:YES];
    //添加成功 提示

}

-(void) removeBookMarkWithUser:(NSString *) userName
                        mzName:(NSString *) mzName
                 periodicalNum:(NSString *) num
                         index:(int) index {
    
    NSString *path = GSPathForFileInDocumentsDirectory(BOOKMARK_PLIST);
    NSString *key = [self convertKeyToSHA1:userName mzName:mzName periodicalNum:num];
    NSString *filename=[GS_DOCUMENTS stringByAppendingPathComponent:BOOKMARK_PLIST];
    
    NSArray *modelsArr = [self fetchBookMarksArrWithUser:userName
                                                  mzName:mzName
                                           periodicalNum:num];
    NSMutableArray *t_modelsArr = [modelsArr mutableCopy];
    [t_modelsArr removeObjectAtIndex:index];
    
    
    NSDictionary *rootDic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSMutableDictionary *t_dic = [rootDic mutableCopy];
    [t_dic setObject:t_modelsArr forKey:key];
    [t_dic writeToFile:filename atomically:YES];
}

@end
