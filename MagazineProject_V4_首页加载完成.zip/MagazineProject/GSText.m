//
//  GSText.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-2-8.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSText.h"


@implementation GSText
@synthesize fontStyle;
@synthesize fontSize;
@synthesize fontColor;
@synthesize bgColor;
//@synthesize appearStyle;
//@synthesize disappearStyle;
@synthesize textContent;
@synthesize isFirstShow;
@synthesize frame;



@end
