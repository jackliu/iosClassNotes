//
//  MYLAppDelegate.h
//  MagazineProject
//
//  Created by shangdejigou on 13-11-28.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RESideMenu.h"

@interface MYLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

//侧边栏按钮
@property (strong, readonly, nonatomic) RESideMenu *sideMenu;

+ (NSInteger)OSVersion;


@end
