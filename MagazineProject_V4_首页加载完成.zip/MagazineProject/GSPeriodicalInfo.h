//
//  GSPeriodicalInfo.h
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-24.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <Foundation/Foundation.h>

//@interface GSPageInfo: NSObject
//@property (strong, nonatomic) NSString *name;
//@property (strong, nonatomic) NSString *path;
//@end

@interface GSTopicInfo : NSObject
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *thumbName;
@property (strong, nonatomic) NSString *path;
@property (strong, nonatomic) NSString *intro;
@property (strong, nonatomic) NSMutableArray *pages;
@end

@interface GSPeriodicalInfo : NSObject
@property (strong, nonatomic) NSString *cover_pageName;
@property (strong, nonatomic) NSString *cover_thumbName;
@property (strong, nonatomic) NSString *cover_contentPath;
@property (strong, nonatomic) NSString *catalog_pageName;
@property (strong, nonatomic) NSString *catalog_thumbName;
@property (strong, nonatomic) NSString *catalog_contentPath;
@property (strong, nonatomic) NSMutableArray *topics;


@end
