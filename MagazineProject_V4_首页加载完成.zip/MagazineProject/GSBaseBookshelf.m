//
//  GSBaseBookshelf.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-17.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSBaseBookshelf.h"


@implementation GSBaseBookshelf
@synthesize aGSPeriodicalDic;
@synthesize selectYear;


- (NSArray *)getPeriodicalArrayForYear:(NSString *)year {
	NSArray *aGSPeriodicalArray = (NSArray *)[self.aGSPeriodicalDic objectForKey:year];
	return aGSPeriodicalArray;
}

- (id)init {
	self = [super init];
	if (self) {
		if (!self.aGSPeriodicalDic) 
		{
			NSMutableDictionary *aNSMutableDictionary = [[NSMutableDictionary alloc] init];
			self.aGSPeriodicalDic = aNSMutableDictionary;
			//[aNSMutableDictionary release];
		}
	}
	return self;
}

@end
