//
//  GSHorizontalView.h
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-25.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ATPagingView.h"

@class GSVerticalView;

@interface GSHorizontalView : UIView <ATPagingViewDelegate> {
    @private
    ATPagingView *_atpView;
    GSVerticalView *_verticalView;
    
    NSArray *_dataSource;
    NSIndexPath *_currentIndexPath;
    //横向
    NSString *verticalNumber;
}

- (id) initWithFrame:(CGRect)frame
      withDataSource:(NSArray *) dataSource_
withCurrentIndexPath:(NSIndexPath *) indexPath_;

@property(strong, nonatomic) NSArray *dataSource;
@property(strong, nonatomic) NSIndexPath *currentIndexPath;
@property(strong, nonatomic) NSString *verticalNumber;

@end
