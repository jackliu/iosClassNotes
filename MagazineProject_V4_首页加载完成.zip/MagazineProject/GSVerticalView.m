//
//  GSVerticalView.m
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-25.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "GSVerticalView.h"
#import "FileOperation.h"

@interface GSVerticalView ()
@property (nonatomic,assign) UIGestureRecognizerState gestureState;
@end

@implementation GSVerticalView

@synthesize currentIndex = _currentIndex;
@synthesize dataSource = _dataSource;
@synthesize atpView = _atpView;
@synthesize catalogIndex = _catalogIndex;

@synthesize gestureState;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _atpView = [[ATPagingView alloc] initWithFrame:frame];
        _atpView.direction = ATPagingViewVertical;
        _atpView.delegate = self;
        [_atpView setGapBetweenPages:0];
        [self addSubview:_atpView];
        [self setUserInteractionEnabled:YES];
        //新增notification,获取下载状态
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(downloadStatus:) name:@"NOTIFICATION_DOWNLOADSTATUS" object:nil];
        //获取手势判断
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideDownIcon:) name:@"NOTIFICATION_HIDEDOWNICON" object:nil];
    }
    return self;
}
-(void)downloadStatus:(NSNotification *)noti
{
    NSDictionary *dic = [noti object];
    //获取下载当前完成的zipname
    NSString *zipName = [dic objectForKey:@"downloadZipInfo"];
    NSString *fileName = [zipName stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    //存在
    NSLog(@"htmlpath is %@",htmlPath);
    if ([htmlPath rangeOfString:fileName].location != NSNotFound) {
        NSLog(@"已存在 下载！");
        [mbHud hide:YES];
        [_atpView reloadData];
    }
}
/*
//隐藏下拉提示icon
- (void)hideDownIcon:(NSNotification *)noti
{
    NSNumber *hide = [noti object];
    if ([hide intValue] == 1) {
        //downTag.frame= CGRectZero;
        //[downTag removeFromSuperview];
        if (downTag.hidden) {
            [downTag fadeOut:0.3f delegate:nil];
        }
        //[downTag setHidden:YES];
        //downTag.frame= CGRectMake(700, 950, 32, 32);
        //[downTag setHidden:YES];
    }
    else {
        //显示下拉icon
//        downTag = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"xiala.png"]];
//        downTag.frame = CGRectMake(self.origin.x +700,self.origin.y + 950, 27, 25);
//        downTag.backgroundColor = [UIColor redColor];
//        [self addSubview:downTag];
//        [self bringSubviewToFront:downTag];
        [downTag setHidden:NO];
        [downTag fadeIn:0.3f delegate:nil];
        //downTag.frame= CGRectZero;
        //[downTag setHidden:NO];
    }
}
*/
-(void) setDataSource:(NSArray *)dataSource {
    _dataSource = dataSource;
    [_atpView reloadData];
//    [_atpView setCurrentPageIndex:0];
}

-(void) setCurrentIndex:(int)currentIndex {
    _currentIndex = currentIndex;
    [_atpView reloadData];
    
    [_atpView setCurrentPageIndex:_currentIndex];
}

#pragma mark - atpagingview delegate
-(NSInteger) numberOfPagesInPagingView:(ATPagingView *)pagingView {
    NSLog(@"vertical count is %d",self.dataSource.count);
    return self.dataSource.count;
    
}

-(UIView *) viewForPageInPagingView:(ATPagingView *)pagingView atIndex:(NSInteger)index {
    UIWebView *webView = (UIWebView *)[pagingView dequeueReusablePage];
    //remove重用的，减少重用的内存
    if (webView) {
        [webView removeFromSuperview];
        webView = nil;
    }
    
    if (!webView) {
        webView = [[UIWebView alloc] initWithFrame:pagingView.frame];
        //webView.delegate = self;
        //关闭其滑动，因为实测中会影响到SCROLLVIEW的自身滑动
        webView.scrollView.scrollEnabled = NO;
    }
    //NSLog(@"vertical current page is %d,%d",pagingView.currentPageIndex,pagingView.pageCount);

    NSString *path = [self.dataSource objectAtIndex:index];
    NSLog(@"vertical path is %@",path);
    htmlPath = [NSString stringWithFormat:@"%@",path];//保存当前html
    mbHud = [MBProgressHUD showHUDAddedTo:self animated:YES];
    mbHud.mode = MBProgressHUDModeIndeterminate;//default
    mbHud.labelText = @"正在加载中";
    mbHud.dimBackground = NO;
    mbHud.delegate = self;
    //[mbHud show:YES];
    //执行请求，完成
    NSString *currentPath = [self.dataSource objectAtIndex:index];
    if ([FileOperation fileExistsAtPath:currentPath]) {
        //存在本地文件就导入webview
        NSLog(@"存在 %@",currentPath);
        [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
        [mbHud hide:YES];
    }
    else {
        NSString *backgroundImage = @"<html><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /></head><body><div type='image' style='position:absolute;top:0px;left:0px'><img class='img' width='768' height='1024' src='crossview_bg.png'/></div></body></html>";
        [webView loadHTMLString:backgroundImage baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
        [mbHud show:YES];
    }
    //webView.allowsInlineMediaPlayback = YES;
    /*
    [mbHud showAnimated:YES whileExecutingBlock:^{
        //执行请求，完成
        NSString *currentPath = [self.dataSource objectAtIndex:index];
        if ([FileOperation fileExistsAtPath:currentPath]) {
            //存在本地文件就导入webview
            NSLog(@"存在 %@",currentPath);
            [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
            //后期后化javascript捕获
//            NSString *str = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
//            NSLog(@"html is %@",[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil]);
            
//            if ([str rangeOfString:@"javascript"].length >0) {
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"NSNOTICATION_JS" object:[NSNumber numberWithBool:YES]];
//            }
        }
        else {
            NSString *backgroundImage = @"<html><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8' /></head><body><div type='image' style='position:absolute;/projects/NEW/Classes/View/GSCrossView.htop:0px;left:0px'><img class='img' width='768' height='1024' src='crossview_bg.png'/></div></body></html>";
            [webView loadHTMLString:backgroundImage baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
        }
    } completionBlock:^{
        [mbHud removeFromSuperview];
        //[webView reload];
    }];
    */
    //[webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
    
    return webView;
}

- (void)currentPageDidChangeInPagingView:(ATPagingView *)pagingView {
   // NSString *pageStr = [NSString stringWithFormat:@"第%d页/共%d页", pagingView.currentPageIndex, pagingView.pageCount];
//    GS_Alert(pageStr);
    //竖向的
    NSString *pageStr = [NSString stringWithFormat:@"%d", pagingView.currentPageIndex];
    NSLog(@"第%d页,共%d页",pagingView.currentPageIndex,pagingView.pageCount);

    [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTIFICATION_REFRENSHLOCATION"
                                                        object:@{@"page" : pageStr,@"pageCount":[NSNumber numberWithInt:pagingView.pageCount]}];
    //NSLog(@" vertical x is %f, y is %f, w is %f,%f",self.origin.x,self.origin.y,self.width,self.height);

}


//开始加载
//- (void)pagingViewWillBeginMoving:(ATPagingView *)pagingView
//{
//    mbHud = [MBProgressmbHud showmbHudAddedTo:self animated:YES];
//    mbHud.mode = MBProgressHUDModeIndeterminate;//default
//    hud.labelText = @"loading";
//    [hud show:YES];
//    if ([FileOperation fileExistsAtPath:htmlPath]) {
//        [hud hide:YES];
//        [hud removeFromSuperview];
//    }
//    else {
//        [hud show:YES];
//    }
//}
//结束加载
- (void)pagingViewDidEndMoving:(ATPagingView *)pagingView {
//    UIWebView *webView = (UIWebView *)[pagingView viewForPageAtIndex:pagingView.previousPageIndex];
//    [webView reload];
    //判断是否存在html文件，没有就保持加载状态
//    if ([FileOperation fileExistsAtPath:htmlPath]) {
//        [hud hide:YES];
//        [hud removeFromSuperview];
//    }
//    else {
//        [hud show:YES];
//    }
    //发现已经下载好并解压了 立即发通知显示并刷新
    
    
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
/*
#pragma UIWebView Delegate
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *currentURL = [webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.innerHTML"];
    NSLog(@"webview url is %@",currentURL);
//    [webView stringByEvaluatingJavaScriptFromString:@"test();"];
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSLog(@"webview path is %@,url is %@",request.mainDocumentURL.relativePath, [request URL].absoluteString);
//    if ( [request.mainDocumentURL.relativePath isEqualToString:@"/click/false"] ) {
//        NSLog( @"not clicked" );
//        return NO;
//    }
//    
//    if ( [request.mainDocumentURL.relativePath isEqualToString:@"/click/true"] ) {        //the image is clicked, variable click is true
//        NSLog( @"image clicked" );
//        return YES;
//    }
    return YES;
    
}
*/

#pragma mark -
#pragma mark MBProgressHUDDelegate methods
- (void)hudWasHidden:(MBProgressHUD *)hud {
	// Remove HUD from screen when the HUD was hidded
	[mbHud removeFromSuperview];
	mbHud = nil;
}

@end
