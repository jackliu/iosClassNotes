//
//  GSPeriodical.h
//  MagazineProject
//
//  Created by shangdejigou on 13-11-29.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSCoverImage.h"

@interface GSPeriodical : NSObject

//<Month value="2012.01">
@property(nonatomic,retain)NSString *dateStr;
//<Periodical>201201</Periodical>
@property(nonatomic,retain)NSString *numberStr;
//<WholePeriodical>201201</WholePeriodical>
@property(nonatomic,retain)NSString *title;
//<FrontCover>2012/201201/009.jpg</FrontCover>
@property(nonatomic,retain)GSCoverImage *coverImage;

@property(nonatomic,retain)NSString *periodicalResourse;
//<Ppath>2012/201201/201201.xml</Ppath>
@property(nonatomic,retain)NSString *periodicalInfoFile;




@end
