//
//  TitleView.m
//  GSPublishSystem
//
//  Created by Baoyifeng on 12-1-19.
//  Copyright 2012 Glavesoft. All rights reserved.
//

#import "GSTitleView.h"


@implementation GSTitleView
@synthesize titleImageView,bookstoreBtn,bookshelfBtn,yearBtn;




@end
