//
//  GSCrossView.h
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-25.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GSHorizontalView;

@interface GSCrossView : UIView {
    @private
    GSHorizontalView* horizontalView;
}

@property(strong, nonatomic) NSArray *dataSource;
@property(strong, nonatomic) NSIndexPath *currentIndexPath;

- (id) initWithFrame:(CGRect)frame
      withDataSource:(NSArray *) dataSource_
withCurrentIndexPath:(NSIndexPath *) indexPath_;

@end
