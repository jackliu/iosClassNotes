//
//  GSBaseViewController.h
//  GSCodeStyle
//
//  Created by Baoyifeng on 11-12-26.
//  Copyright 2011 Glavesoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GSBaseViewController : UIViewController {

}

@end
