//
//  MYLAppDelegate.h
//  MagazineProject
//
//  Created by shangdejigou on 13-11-28.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
