//
//  DownloadManager.h
//  GSMagazinePublish
//
//  Created by 蒋 宇 on 12-12-7.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "ASIHTTPRequest.h"

@interface DownloadManager : ASIHTTPRequest
+(void) downloadResource:(NSString *) resPath;
@end
