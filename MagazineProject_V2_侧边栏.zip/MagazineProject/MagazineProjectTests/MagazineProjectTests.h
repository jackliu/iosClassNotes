//
//  MagazineProjectTests.h
//  MagazineProjectTests
//
//  Created by shangdejigou on 13-11-28.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MagazineProjectTests : SenTestCase

@end
