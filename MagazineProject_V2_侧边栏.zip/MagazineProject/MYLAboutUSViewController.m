//
//  MYLAboutUSViewController.m
//  MagazineProject
//
//  Created by shangdejigou on 13-11-29.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import "MYLAboutUSViewController.h"

@interface MYLAboutUSViewController ()

@end

@implementation MYLAboutUSViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:1.000 green:0.859 blue:0.487 alpha:1.000];
    [self.navigationController.navigationBar setTitleTextAttributes:@{UITextAttributeTextColor: [UIColor whiteColor]}];
    if ([self.navigationController.navigationBar respondsToSelector:@selector(setBarTintColor:)]) {
        [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
        [self.navigationController.navigationBar performSelector:@selector(setBarTintColor:) withObject:[UIColor blueColor]];
    } else {
        [self.navigationController.navigationBar setTintColor:[UIColor blueColor]];
    }
}

#ifdef __IPHONE_7_0
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
#endif

@end
