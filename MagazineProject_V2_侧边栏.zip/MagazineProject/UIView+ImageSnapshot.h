//
//  UIView+ImageSnapshot.h
//  RESideMenuExample
//
//  Created by Sam Oakley on 22/07/2013.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ImageSnapshot)
-(UIImage*) snapshotImage;
@end
