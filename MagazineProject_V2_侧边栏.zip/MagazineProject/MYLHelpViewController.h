//
//  MYLHelpViewController.h
//  MagazineProject
//
//  Created by shangdejigou on 13-11-29.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"


@interface MYLHelpViewController : RootViewController

@end
