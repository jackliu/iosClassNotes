//
//  GS_Util.m
//  GS_Magazine
//
//  Created by glave on 12-12-17.
//  Copyright (c) 2012年 glave. All rights reserved.
//

#import "GS_Util.h"

void GS_Alert(NSString* message) {
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                     message:message delegate:nil
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:nil];
    [alert show];
}

@implementation GS_Util
+(NSString *) SHA1:(NSString *) str{
    const char *cstr = [str cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:str.length];
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    CC_SHA1(data.bytes, data.length, digest);
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}

+(UIImage *) relectionImage:(UIImage *) img {
    // Modify the image name accordingly
	UIImage *image = img;
                      
    UIImageView *imageView = [[UIImageView alloc]initWithImage:image];
                      
    CGImageRef imageToSplit = image.CGImage;
    // I'm using the lower 1/3 of the image only
    CGImageRef partOfImageAsCG = CGImageCreateWithImageInRect(imageToSplit, CGRectMake(0,(image.size.height*2)/3,image.size.width, image.size.height/3));
    // Create an UIImage instance of the image part
    UIImage *partOfImage = [UIImage imageWithCGImage:partOfImageAsCG];
    // Flip the UIImage mirrored upside-down
    UIImage* flippedImage = [UIImage imageWithCGImage:partOfImage.CGImage scale:1.0 orientation:  UIImageOrientationDownMirrored];
    
    UIImageView *reflectionView = [[UIImageView alloc]initWithImage:flippedImage];
    reflectionView.frame = CGRectMake(0, image.size.height, image.size.width, image.size.height/2);
                      
    // Initialize ImageContext with the combined sizes of the imageView (original image)and the reflectionView
    UIGraphicsBeginImageContext(CGSizeMake(imageView.image.size.width,imageView.image.size.height+reflectionView.image.size.height));
    // Creates an CGRect with the imageView content
    CGRect imageRect = CGRectMake(0, 0, imageView.image.size.width, imageView.image.size.height);
    // Creates an CGRect with the reflectionView content
    CGRect reflectionRect = CGRectMake(0, imageView.image.size.height, reflectionView.image.size.width, reflectionView.image.size.height);
    //shows the imageView at full size
    [imageView.image drawInRect:imageRect];
    //displays the reflection with 0.5 transparent
    [reflectionView.image drawInRect:reflectionRect blendMode:kCGBlendModeScreen alpha:0.5];

    // Creates an UIImage instance of the resulting image context
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return resultingImage;
}

@end
