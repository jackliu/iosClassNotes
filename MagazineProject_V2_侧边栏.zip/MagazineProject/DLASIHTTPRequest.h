//
//  DLASIHTTPRequest.h
//  GSMagazinePublish
//
//  Created by on 12-12-4.
//  Copyright (c) 2012年 zheng jie. All rights reserved.
//

#import "ASIHTTPRequest.h"
#import <CommonCrypto/CommonDigest.h> // Need to import for CC_MD5 access
//给ASIHTTPRequest添加方法
//@interface ASIHTTPRequest (DownloaderItem)

@interface DLASIHTTPRequest : ASIHTTPRequest

/**
 * @brief	资源的保存路径和临时下载路径的下载设置(ASIHTTPRequest)
 * @param	资源的保存路径和临时下载路径
 * @return
 * @note	当资源的保存路径和临时下载路径没有这个目录时，创建文件路径，并且临时文件名用MD5加密方式命名
 */
- (void)breakpointDownloadSetting:(NSString *)savePath andtempFolderPath:(NSString *)tempFolderPath;

/**
 * @brief	MD5加密
 * @param	需要加密的字符串
 * @return	加密过后的字符串
 * @note	添加#import <CommonCrypto/CommonDigest.h>
 */
- (NSString *)md5:(NSString *)anAppendingFileName;
@end