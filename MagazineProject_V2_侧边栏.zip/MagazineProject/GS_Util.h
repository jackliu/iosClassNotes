//
//  GS_Util.h
//  GS_Magazine
//
//  Created by glave on 12-12-17.
//  Copyright (c) 2012年 glave. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIViewAdditions.h"
#import <CommonCrypto/CommonDigest.h>


#define GS_DEVICE_IPHONE() ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
#define GS_DEVICE_IPAD() ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

#define GS_DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]


static inline BOOL GSIsLandSacpe(UIView *view) {
    return view.width>view.height;
}

static inline NSString *GSPathForFileInDocumentsDirectory(NSString *filename) {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:filename];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    return ([fileManager fileExistsAtPath:path] ? path : @"");
}

static inline NSString *GSPathForFileInCacheSDirectory(NSString *filename) {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesPath = [paths objectAtIndex:0];
    NSString *path = [cachesPath stringByAppendingPathComponent:filename];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    return ([fileManager fileExistsAtPath:path] ? path : @"");
}

//NSData file
static inline void GSSaveBundleFileInDocumentsDirectory(NSData *file, NSString *filename) {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesPath = [paths objectAtIndex:0];
    NSString *filePath = [cachesPath stringByAppendingPathComponent:filename];
    [file writeToFile:filePath atomically:YES];
    
    /* 之后要创建文件夹分类
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *testDirectory = [documentsDirectory stringByAppendingPathComponent:@"ListFiles"];
     */
}

static inline void GSSaveThumbsInMagazineDirectory(NSData *file, NSString *filename, NSString *magazineNumber) {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesPath = [paths objectAtIndex:0];
    NSString *filePath = [[cachesPath stringByAppendingPathComponent:magazineNumber] stringByAppendingPathComponent:filename];
    [file writeToFile:filePath atomically:YES];
}

static inline NSString *GSPathForFileInBundleDirectory(NSString *filename, NSString *dirName) {
    return [[[NSBundle mainBundle] resourcePath] stringByAppendingFormat:@"/%@/%@", dirName, filename];
}

void GS_Alert(NSString* message);

@interface GS_Util : NSObject
+(NSString *) SHA1:(NSString *) str;
+(UIImage *) relectionImage:(UIImage *) img;
@end
