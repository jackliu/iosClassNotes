//
//  DemoViewController.h
//  RESideMenuExample
//
//  Created by Roman Efimov on 6/14/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"

@interface DemoViewController : RootViewController

@end
