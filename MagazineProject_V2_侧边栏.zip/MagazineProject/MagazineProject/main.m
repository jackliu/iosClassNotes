//
//  main.m
//  MagazineProject
//
//  Created by shangdejigou on 13-11-28.
//  Copyright (c) 2013年 LiuLiLi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MYLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MYLAppDelegate class]));
    }
}
