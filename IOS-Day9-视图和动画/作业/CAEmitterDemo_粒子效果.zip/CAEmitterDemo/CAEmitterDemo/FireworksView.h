//
//  EmitterView.h
//  CAEmitterDemo
//
//  Created by Shawn Welch on 10/6/11.
//  Copyright (c) 2011 anythingsimple.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface FireworksView : UIView{
 
    
}

- (void)launchFirework;

@end
