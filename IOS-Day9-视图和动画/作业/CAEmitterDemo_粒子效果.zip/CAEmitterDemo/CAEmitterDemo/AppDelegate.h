//
//  AppDelegate.h
//  CAEmitterDemo
//
//  Created by Shawn Welch on 10/6/11.
//  Copyright (c) 2011 anythingsimple.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
