//
//  DemoViewController.h
//  DemoCoreAnimation
//
//  Created by Shawn Welch on 1/23/11.
//  Copyright 2011 anythingsimple.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DemoCAView.h"


@interface DemoViewController : UIViewController {

	IBOutlet UIButton *colors;
	IBOutlet UIButton *rotate;
	IBOutlet UIButton *flip;
    IBOutlet UIButton *drop;
	
	IBOutlet DemoCAView *demoView;
	
}

@property (nonatomic, retain) IBOutlet UIButton *colors, *rotate, *flip, *drop;
@property (nonatomic, retain) IBOutlet UIView *demoView;

- (IBAction)colorsPressed:(id)sender;
- (IBAction)rotatePressed:(id)sender;
- (IBAction)flipPressed:(id)sender;
- (IBAction)dropPressed:(id)sender;


@end
