//
//  DemoCAView.m
//  DemoCoreAnimation
//
//  Created by Shawn Welch on 1/23/11.
//  Copyright 2011 anythingsimple.com. All rights reserved.
//

#import "DemoCAView.h"
#import <QuartzCore/QuartzCore.h>

@implementation DemoCAView

// Set up our ball and box instance variables
- (void)setupInstanceVariables{
    ball = [[UIView alloc] initWithFrame:CGRectMake(20, 40, 20, 20)];
    ball.backgroundColor = [UIColor blackColor];
    box = [[UIView alloc] initWithFrame:CGRectMake(20, 80, 200, 200)];
    box.backgroundColor = [UIColor redColor];
    [self addSubview:box];
    [self addSubview:ball];
}

// Animate Colors using Core Anination
- (void)animateColors{
	
    //Set up an transition animation of type reveal
	CATransition *trans = [CATransition animation];
	trans.type = kCATransitionReveal;
	trans.subtype = kCATransitionFromLeft;
	trans.duration = .5;
	
    //Apply the transition to our box
	[box.layer addAnimation:trans forKey:@"transition"];
	box.layer.backgroundColor = [UIColor blueColor].CGColor;

	
    // Set up a new keyframe animation for colors
    // Cycle the animation values through yellow, green and blue
    // apply the animation parameters and set to our box layer
	CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
	animation.values = [NSArray arrayWithObjects:
						(id)box.layer.backgroundColor,
						(id)[UIColor yellowColor].CGColor,
						(id)[UIColor greenColor].CGColor,
						(id)[UIColor blueColor].CGColor,nil];
	animation.duration = 3;
	animation.autoreverses = YES;
	[box.layer addAnimation:animation forKey:@"backgroundColor"];
	
}

- (void)animateFlip{

	//Step 1: Create basic y-axis rotation animation
	CABasicAnimation *flip = [CABasicAnimation 
							  animationWithKeyPath:@"transform.rotation.y"];
    flip.toValue = [NSNumber numberWithDouble:-M_PI];
	
	//Step 2: Create Basic scale animation
	CABasicAnimation *scale = [CABasicAnimation 
							   animationWithKeyPath:@"transform.scale"];
    scale.toValue = [NSNumber numberWithDouble:.9];
	scale.duration = .5;
    scale.autoreverses = YES;
    
    //Step 3: Combine scale and flip into 1 animation group
    CAAnimationGroup *group = [CAAnimationGroup animation];
    group.animations = [NSArray arrayWithObjects:flip, scale, nil];
	group.timingFunction = [CAMediaTimingFunction 
							functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	group.duration = 1;
	group.fillMode = kCAFillModeForwards;
    group.removedOnCompletion = NO;
	
	//Step 4: Add animation group to our layer
	[box.layer addAnimation:group forKey:@"flip"];
	
}

- (void)animateRotate{
    // Set up a basic animation for rotation on z axis (spinning)
	CABasicAnimation *spin = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
   
    // Set the value of the spin to 2*pi, this is 1 complete rotation in radians
	spin.toValue = [NSNumber numberWithDouble:M_PI*2];
	
    // Sping for a really long time.....
    spin.repeatCount = 1e100;
	spin.duration = 1.5; // duration to animate a full revolution of 2*Pi radians.
	[box.layer addAnimation:spin forKey:@"transform"];
}

- (void)animateDrop{
    
    // Set up our keyframe animation
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
    CGMutablePathRef aPath = CGPathCreateMutable();
    CGPathMoveToPoint(aPath,nil,20,40);        //Origin Point
    CGPathAddCurveToPoint(aPath,nil, 160,30,   //Control Point 1
                                     220,220,  //Control Point 2
                                     240,380); // End Point
    animation.rotationMode = @"auto";
    animation.path = aPath;
    animation.duration = 1;
    animation.timingFunction = [CAMediaTimingFunction 
                                functionWithName:kCAMediaTimingFunctionEaseIn];
    
    [ball.layer addAnimation:animation forKey:@"position"];
    CFRelease(aPath);
}

- (void)dealloc {
    [super dealloc];
}


@end
