//
//  DemoCoreAnimationAppDelegate.h
//  DemoCoreAnimation
//
//  Created by Shawn Welch on 1/23/11.
//  Copyright 2011 anythingsimple.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoCoreAnimationAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

