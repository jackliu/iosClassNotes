//
//  DemoViewController.m
//  DemoCoreAnimation
//
//  Created by Shawn Welch on 1/23/11.
//  Copyright 2011 anythingsimple.com. All rights reserved.
//

#import "DemoViewController.h"


@implementation DemoViewController
@synthesize rotate, flip, colors, drop, demoView;



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    [demoView setupInstanceVariables];
}


// IBActions called from DemoViewController.xib
- (IBAction)colorsPressed:(id)sender{
	[demoView animateColors];
}
- (IBAction)rotatePressed:(id)sender{
	[demoView animateRotate];
}
- (IBAction)flipPressed:(id)sender{
	[demoView animateFlip];
}

- (IBAction)dropPressed:(id)sender{
    [demoView animateDrop];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
