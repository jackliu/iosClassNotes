//
//  DemoCAView.h
//  DemoCoreAnimation
//
//  Created by Shawn Welch on 1/23/11.
//  Copyright 2011 anythingsimple.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DemoCAView : UIView {

    UIView *ball;
    UIView *box;

}

- (void)setupInstanceVariables;
- (void)animateColors;
- (void)animateFlip;
- (void)animateRotate;
- (void)animateDrop;

@end
